package net.cursedvalley.mobs;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * End Golem'ler.
 *
 * Belirli bir kutu bolgede sabit sayida golem tutar. Biri olunce geri sayim
 * baslar; sure dolunca bolgede rastgele bir noktada yenisi dogar.
 *
 * Gorunum: vanilla IronGolem gorunmez olur, uzerine EndGolemModel'in item_display
 * parcalari takilir. Can vanilla can sistemidir (650 < 1024 siniri), yani hasar,
 * olum ve ganimet kutusu normal akistan isler.
 *
 * Davranis: bolgenin ortasindan "leash-radius" blok uzaklasirsa oyunculari
 * birakir, ortaya doner ve donerken cani hizla dolar. Vurusu elle islenir (vanilla yapay zeka kapatilir).
 */
public final class EndGolemPack {

    /** Golemleri isaretleyen etiket. */
    public static final String TAG = "cv_endgolem";
    /** /cvmobs drop add end_golem <oran> */
    public static final String DROP_KEY = "end_golem";
    public static final String DISPLAY_NAME = "End Golem";

    /** Eski surumden kalan kurbagalar: bulunursa silinir. */
    private static final String LEGACY_FROG_TAG = "cv_frog";

    private final JavaPlugin plugin;

    // --- ayarlar ---
    private boolean enabled = true;
    private boolean customModel = true;
    private String worldName = "cursedvalley";
    private int count = 5;
    private double health = 650.0;
    private double sight = 7.0;
    private double meleeDamage = 30.0;
    private double meleeReach = 3.2;
    private int meleeCooldownTicks = 20;
    private int respawnSeconds = 15;
    /** Yurume hizi (nitelik degeri). Iron Golem 0.25; bu biraz daha yavas. */
    private double speed = 0.14;
    /** Vanilla Iron Golem 2.7 blok boyunda; model boyuna gore olceklenir. */
    private static final double BASE_HEIGHT = 2.7;
    private double leashRadius = 20.0;
    private long angerMs = 20000L;
    private float scale = 0.75f;
    /** Her regenSeconds saniyede bu kadar can yenilenir. */
    private double regenAmount = 40.0;
    private int regenSeconds = 10;

    private int minX, minY, minZ, maxX, maxY, maxZ;

    private static final class Golem {
        final UUID id;
        EndGolemModel model;
        boolean returning;
        long lastMelee = -1000;
        UUID provoker;
        long provokedUntil;

        Golem(UUID id) {
            this.id = id;
        }
    }

    private final Map<UUID, Golem> alive = new LinkedHashMap<>();
    private final List<Integer> respawnTimers = new ArrayList<>();
    private int tickCounter;

    public EndGolemPack(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    // ==================== AYAR ====================

    public void configure(FileConfiguration c, String world) {
        this.worldName = world;
        String p = "end-golems.";
        enabled = c.getBoolean(p + "enabled", true);
        customModel = c.getBoolean(p + "custom-model", true);
        count = Math.max(0, c.getInt(p + "count", 5));
        health = Math.max(1.0, Math.min(1024.0, c.getDouble(p + "health", 650.0)));
        sight = Math.max(1.0, c.getDouble(p + "sight-range", 7.0));
        meleeDamage = Math.max(0.0, c.getDouble(p + "melee-damage", 30.0));
        meleeReach = Math.max(1.0, c.getDouble(p + "melee-reach", 3.2));
        meleeCooldownTicks = Math.max(5, c.getInt(p + "melee-cooldown-ticks", 20));
        respawnSeconds = Math.max(0, c.getInt(p + "respawn-seconds", 15));
        speed = Math.max(0.05, Math.min(1.0, c.getDouble(p + "speed", 0.14)));
        leashRadius = Math.max(5.0, c.getDouble(p + "leash-radius", 20.0));
        angerMs = Math.max(1, c.getInt(p + "anger-seconds", 20)) * 1000L;
        regenAmount = Math.max(0.0, c.getDouble(p + "regen-amount", 40.0));
        regenSeconds = Math.max(1, c.getInt(p + "regen-seconds", 10));
        scale = (float) Math.max(0.3, Math.min(3.0, c.getDouble(p + "scale", 0.75)));

        int x1 = c.getInt(p + "region.x1", 10);
        int y1 = c.getInt(p + "region.y1", -51);
        int z1 = c.getInt(p + "region.z1", 215);
        int x2 = c.getInt(p + "region.x2", 25);
        int y2 = c.getInt(p + "region.y2", -51);
        int z2 = c.getInt(p + "region.z2", 200);
        minX = Math.min(x1, x2); maxX = Math.max(x1, x2);
        minY = Math.min(y1, y2); maxY = Math.max(y1, y2);
        minZ = Math.min(z1, z2); maxZ = Math.max(z1, z2);
    }

    private World world() {
        return Bukkit.getWorld(worldName);
    }

    /** Bolgenin ortasi -- disari cikan golemin donecegi nokta. */
    private Location center() {
        World w = world();
        if (w == null) return null;
        Location at = new Location(w,
                (minX + maxX + 1) / 2.0,
                minY,
                (minZ + maxZ + 1) / 2.0);
        return Ground.findNear(at, minY);
    }

    // ==================== DOGUS ====================

    private Location randomSpot() {
        World w = world();
        if (w == null) return null;
        var r = ThreadLocalRandom.current();
        double x = minX + 0.5 + r.nextDouble() * Math.max(0, maxX - minX);
        double z = minZ + 0.5 + r.nextDouble() * Math.max(0, maxZ - minZ);
        // Arena yeraltinda; yuzeye dogurmamak icin referans Y ile zemin aranir.
        return Ground.findNear(new Location(w, x, minY, z), minY);
    }

    /** Yeni dogan golem digerlerinin icine girmesin (en az MIN_GAP blok arayla). */
    private static final double MIN_GAP = 3.0;

    private boolean farFromOthers(Location c) {
        for (UUID id : alive.keySet()) {
            Entity o = Bukkit.getEntity(id);
            if (o == null || o.isDead() || !o.getWorld().equals(c.getWorld())) continue;
            if (o.getLocation().distanceSquared(c) < MIN_GAP * MIN_GAP) return false;
        }
        return true;
    }

    private void spawnOne() {
        Location at = null;
        for (int i = 0; i < 40; i++) {
            Location c = randomSpot();
            if (c == null) return;
            if (farFromOthers(c)) { at = c; break; }
            if (i == 39) at = c;   // yer bulunamazsa son aday
        }
        if (at == null) return;
        World w = at.getWorld();

        IronGolem g = w.spawn(at, IronGolem.class, e -> {
            e.addScoreboardTag(TAG);
            // Kalici: chunk bosalinca silinirse "oldu" sanip yenisi dogardi.
            // Sunucu yeniden acilinca start() hepsini temizleyip bastan dogurur.
            e.setPersistent(true);
            e.setRemoveWhenFarAway(false);
            e.setCanPickupItems(false);
            e.setSilent(true);

            var maxAttr = e.getAttribute(Attribute.MAX_HEALTH);
            if (maxAttr != null) maxAttr.setBaseValue(health);
            e.setHealth(health);

            // Hitbox modele gore: Iron Golem 1.4 x 2.7; model boyuna olceklenir
            // (en/boy orani modele en yakin vanilla yaratik).
            var sc = e.getAttribute(Attribute.SCALE);
            if (sc != null) sc.setBaseValue(EndGolemModel.HEIGHT * scale / BASE_HEIGHT);

            var mv = e.getAttribute(Attribute.MOVEMENT_SPEED);
            if (mv != null) mv.setBaseValue(speed);

            // Vanilla yapay zeka (koy savunmasi, kendi vurusu, hedef secimi) kapatilir:
            // yurume ve vurus bu sinifta yonetilir. Yoksa hasar iki kez islerdi.
            Bukkit.getMobGoals().removeAllGoals(e);
            e.setPlayerCreated(false);
            var fr = e.getAttribute(Attribute.FOLLOW_RANGE);
            if (fr != null) fr.setBaseValue(leashRadius + 20.0);
            var at2 = e.getAttribute(Attribute.ATTACK_DAMAGE);
            if (at2 != null) at2.setBaseValue(meleeDamage);

            e.customName(nameOf(health, health));
            e.setCustomNameVisible(!customModel);
        });

        Golem golem = new Golem(g.getUniqueId());
        if (customModel) {
            golem.model = new EndGolemModel(plugin, scale);
            golem.model.spawn(g);
        }
        alive.put(g.getUniqueId(), golem);

        w.playSound(at, Sound.ENTITY_ENDERMAN_TELEPORT, SoundCategory.HOSTILE, 1.2f, 0.5f);
        w.spawnParticle(org.bukkit.Particle.PORTAL, at.clone().add(0, 2, 0), 40, 0.6, 1.2, 0.6, 0.4);
    }

    /** Baslangicta / reload'da temiz sayfa acar. */
    public void start() {
        removeAll();
        World w = world();
        if (w != null) cleanupLeftovers(w);
        if (!enabled) return;
        for (int i = 0; i < count; i++) spawnOne();
    }

    // ==================== TICK ====================

    /** Her tick cagrilir; model 2 tick'te, davranis 5 tick'te bir islenir. */
    public void tick() {
        if (!enabled) return;
        World w = world();
        if (w == null) return;
        tickCounter++;

        // --- olum tespiti ---
        // Bukkit.getEntity() yuklenmemis chunk'taki varlik icin null doner; bu
        // "oldu" demek DEGILDIR. Sayac sadece gercekten olen icin baslar.
        Iterator<Map.Entry<UUID, Golem>> it = alive.entrySet().iterator();
        while (it.hasNext()) {
            var entry = it.next();
            Entity e = Bukkit.getEntity(entry.getKey());
            if (e == null) continue;
            if (e.isDead() || !e.isValid()) {
                if (entry.getValue().model != null) entry.getValue().model.remove();
                it.remove();
                respawnTimers.add(respawnSeconds * 20);
            }
        }

        for (int i = respawnTimers.size() - 1; i >= 0; i--) {
            int left = respawnTimers.get(i) - 1;
            if (left <= 0) {
                respawnTimers.remove(i);
                spawnOne();
            } else {
                respawnTimers.set(i, left);
            }
        }

        // Kayit eksik kaldiysa (ornegin /kill) eksigi geri sayima ekle.
        while (alive.size() + respawnTimers.size() < count) {
            respawnTimers.add(respawnSeconds * 20);
        }

        if (tickCounter % 2 == 0) modelStep();
        if (tickCounter % (regenSeconds * 20) == 0) regenStep();
        if (tickCounter % 100 == 0) sweep(w);
        if (tickCounter % 5 == 0) behaviorStep();
    }

    /** Her regenSeconds saniyede bir butun golemlerin cani regenAmount kadar dolar. */
    private void regenStep() {
        if (regenAmount <= 0) return;
        for (UUID id : alive.keySet()) {
            Entity e = Bukkit.getEntity(id);
            if (!(e instanceof IronGolem g) || g.isDead()) continue;
            double max = maxHealthOf(g);
            if (g.getHealth() < max) g.setHealth(Math.min(max, g.getHealth() + regenAmount));
        }
    }

    /** Takipte olmayan golem / parca birikmesin. */
    private void sweep(World w) {
        for (Entity e : w.getEntities()) {
            if (!(e instanceof IronGolem g)) continue;
            if (!g.getScoreboardTags().contains(TAG)) continue;
            if (!alive.containsKey(g.getUniqueId())) g.remove();
        }
    }

    private void modelStep() {
        if (!customModel) return;
        for (Map.Entry<UUID, Golem> en : alive.entrySet()) {
            Entity e = Bukkit.getEntity(en.getKey());
            if (!(e instanceof IronGolem g) || g.isDead()) continue;
            Golem golem = en.getValue();
            if (golem.model == null) golem.model = new EndGolemModel(plugin, scale);
            // Chunk bosalip yuklenince parcalar silinmis olabilir: yeniden tak.
            if (!golem.model.valid()) golem.model.spawn(g);
            golem.model.tick(g, 2);
        }
    }

    private void behaviorStep() {
        Location home = center();
        if (home == null) return;

        for (Map.Entry<UUID, Golem> en : new ArrayList<>(alive.entrySet())) {
            Entity e = Bukkit.getEntity(en.getKey());
            if (!(e instanceof IronGolem g) || g.isDead()) continue;
            Golem golem = en.getValue();
            Location loc = g.getLocation();

            double max = maxHealthOf(g);
            double dHome = loc.distance(home);

            // --- donus modu ---
            if (golem.returning) {
                g.setTarget(null);
                g.setHealth(Math.min(max, g.getHealth() + max * 0.05));
                updateName(golem, g, max);
                if (dHome < 6.0) {
                    golem.returning = false;
                } else if (dHome > leashRadius + 15.0) {
                    g.teleport(home);   // yolu bulamadiysa beklemeden don
                } else {
                    g.getPathfinder().moveTo(home, 1.0);
                }
                continue;
            }
            if (dHome > leashRadius) {
                golem.returning = true;
                g.setTarget(null);
                golem.provoker = null;
                continue;
            }

            Player target = pickTarget(golem, g, loc);
            updateName(golem, g, max);

            if (target == null) {
                g.setTarget(null);
                // Dolasip uzaklastiysa yavasca eve don (cani hizla dolmaz).
                if (dHome > 8.0) g.getPathfinder().moveTo(home, 0.7);
                continue;
            }

            g.setTarget(target);
            g.getPathfinder().moveTo(target.getLocation(), 1.0);
            g.lookAt(target);

            tryAttack(golem, g, target);
        }
    }

    /** Pasif: yalnizca kendisine vuran oyuncuya saldirir. */
    private Player pickTarget(Golem golem, IronGolem g, Location loc) {
        if (golem.provoker != null && System.currentTimeMillis() < golem.provokedUntil) {
            Player p = Bukkit.getPlayer(golem.provoker);
            if (valid(p, g)) return p;
        }
        golem.provoker = null;
        return null;
    }

    private boolean valid(Player p, IronGolem g) {
        return p != null && p.isOnline() && !p.isDead()
                && p.getWorld().equals(g.getWorld())
                && p.getGameMode() != GameMode.SPECTATOR
                && p.getGameMode() != GameMode.CREATIVE;
    }

    private void tryAttack(Golem golem, IronGolem g, Player target) {
        long now = g.getTicksLived();
        if (now - golem.lastMelee < meleeCooldownTicks) return;

        Location a = g.getLocation(), b = target.getLocation();
        double dx = a.getX() - b.getX(), dz = a.getZ() - b.getZ();
        if (Math.sqrt(dx * dx + dz * dz) > meleeReach || Math.abs(a.getY() - b.getY()) > 3.5) return;

        golem.lastMelee = now;
        if (golem.model != null) golem.model.playAttack();
        g.getWorld().playSound(a, Sound.ENTITY_IRON_GOLEM_ATTACK, SoundCategory.HOSTILE, 1.4f, 0.6f);

        // Vurus kollar inerken (8 tick sonra) isler; o ana kadar kacan yemez.
        UUID gid = g.getUniqueId(), pid = target.getUniqueId();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Entity ge = Bukkit.getEntity(gid);
            Player p = Bukkit.getPlayer(pid);
            if (!(ge instanceof IronGolem gg) || gg.isDead() || p == null || p.isDead()) return;
            if (!p.getWorld().equals(gg.getWorld())) return;
            Location ga = gg.getLocation(), pb = p.getLocation();
            double ddx = ga.getX() - pb.getX(), ddz = ga.getZ() - pb.getZ();
            if (Math.sqrt(ddx * ddx + ddz * ddz) > meleeReach + 1.0) return;
            if (Math.abs(ga.getY() - pb.getY()) > 3.5) return;
            if (meleeDamage > 0) p.damage(meleeDamage, gg);
            gg.getWorld().playSound(pb, Sound.ENTITY_GENERIC_EXPLODE, SoundCategory.HOSTILE, 0.5f, 1.7f);
        }, 8L);
    }

    /** Can yazisini hem vanilla isme hem modelin text_display'ine yazar. */
    private void updateName(Golem golem, IronGolem g, double max) {
        Component name = nameOf(g.getHealth(), max);
        g.customName(name);
        if (golem.model != null) golem.model.setName(name);
    }

    private double maxHealthOf(LivingEntity e) {
        var a = e.getAttribute(Attribute.MAX_HEALTH);
        return a != null ? a.getValue() : health;
    }

    /** Overlord'daki gibi "ad + can / azami can" yazisi. */
    private static Component nameOf(double hp, double max) {
        int pct = (int) Math.round(100.0 * hp / Math.max(1.0, max));
        return Component.text(DISPLAY_NAME + " ", NamedTextColor.DARK_PURPLE)
                .append(Component.text(Math.round(hp) + " / " + Math.round(max),
                        pct > 50 ? NamedTextColor.GREEN
                                 : pct > 25 ? NamedTextColor.GOLD : NamedTextColor.RED));
    }

    // ==================== OLAYLAR ====================

    public boolean isGolem(Entity e) {
        return e != null && e.getScoreboardTags().contains(TAG);
    }

    /** Bir oyuncu golemi vurdu: gorus disindan olsa da 8 sn kovalar. */
    public void provoke(Entity victim, Player attacker) {
        Golem g = alive.get(victim.getUniqueId());
        if (g == null || attacker == null) return;
        g.provoker = attacker.getUniqueId();
        g.provokedUntil = System.currentTimeMillis() + angerMs;
        victim.getWorld().playSound(victim.getLocation(), Sound.ENTITY_IRON_GOLEM_HURT,
                SoundCategory.HOSTILE, 1.0f, 0.55f);
    }

    /** Golem olunce: parcalar hemen silinir, olum sesi calar. */
    public void handleDeath(LivingEntity dead) {
        Golem g = alive.get(dead.getUniqueId());
        if (g != null && g.model != null) g.model.remove();
        Location at = dead.getLocation();
        World w = at.getWorld();
        w.playSound(at, Sound.ENTITY_IRON_GOLEM_DEATH, SoundCategory.HOSTILE, 1.6f, 0.5f);
        w.playSound(at, Sound.ENTITY_ENDERMAN_DEATH, SoundCategory.HOSTILE, 1.4f, 0.4f);
        w.spawnParticle(org.bukkit.Particle.PORTAL, at.clone().add(0, 2, 0), 80, 0.8, 1.5, 0.8, 0.5);
    }

    // ==================== TEMIZLIK ====================

    public void removeAll() {
        for (Map.Entry<UUID, Golem> en : alive.entrySet()) {
            if (en.getValue().model != null) en.getValue().model.remove();
            Entity e = Bukkit.getEntity(en.getKey());
            if (e != null) e.remove();
        }
        alive.clear();
        respawnTimers.clear();
    }

    /** Sunucu cokerse / eski surumden geride kalanlari siler (kurbagalar dahil). */
    public static void cleanupLeftovers(World w) {
        for (Entity e : w.getEntities()) {
            var tags = e.getScoreboardTags();
            if (tags.contains(TAG) || tags.contains(LEGACY_FROG_TAG)) e.remove();
        }
        EndGolemModel.cleanupLeftovers(w);
    }

    public int aliveCount() {
        return alive.size();
    }

    public int pendingCount() {
        return respawnTimers.size();
    }

    public boolean isEnabled() {
        return enabled;
    }
}
