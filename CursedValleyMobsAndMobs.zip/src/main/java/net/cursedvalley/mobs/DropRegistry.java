package net.cursedvalley.mobs;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Drop kayitlari.
 *
 * Her yaratik icin bir liste tutulur; listedeki HER esyanin kendi dusme orani vardir.
 * Boss oldugunde her kayit ayri ayri zar atar -- yani hicbiri dusmeyebilir,
 * biri dusebilir, sansliysa birkaci birden dusebilir.
 *
 * Kayit komutla eklenir: /cvmobs drop add <yaratik> <oran>  (elindeki esya ile)
 */
public final class DropRegistry {

    /** Tek bir drop kaydi: esya + kendi dusme orani (0.0 - 1.0). */
    public record Entry(ItemStack item, double chance) {

        public Map<String, Object> toMap() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("item", item);
            m.put("chance", chance);
            return m;
        }
    }

    /** yaratik adi (kucuk harf) -> kayitlar */
    private final Map<String, List<Entry>> tables = new LinkedHashMap<>();

    public static String normalize(String mob) {
        String m = mob == null ? "" : mob.toLowerCase(Locale.ROOT);
        return switch (m) {
            case "kristal", "lanetli_kristal" -> "crystal";
            case "overlord_klon", "mini_overlord", "klon" -> "overlord_clone";
            case "son_golem", "end_golem", "golem" -> "end_golem";
            default -> m;
        };
    }

    /** Kayitli drop tablosu olan yaratik adlari (tab tamamlama icin). */
    public java.util.Set<String> mobNames() {
        return new java.util.LinkedHashSet<>(tables.keySet());
    }

    public List<Entry> entries(String mob) {
        return tables.computeIfAbsent(normalize(mob), k -> new ArrayList<>());
    }

    public void add(String mob, ItemStack item, double chance) {
        ItemStack copy = item.clone();
        entries(mob).add(new Entry(copy, Math.max(0.0, Math.min(1.0, chance))));
    }

    /** 1 tabanli sira numarasiyla siler; basarisizsa false. */
    public boolean remove(String mob, int oneBasedIndex) {
        List<Entry> list = entries(mob);
        int i = oneBasedIndex - 1;
        if (i < 0 || i >= list.size()) return false;
        list.remove(i);
        return true;
    }

    public void clear(String mob) {
        entries(mob).clear();
    }

    // ---- RPG kurallari: kademe tablosu + sans bonusu + garantili drop ----

    /** Tum yaratiklar icin ortak cop havuzu (DropByDrop). Config'e yazilmaz. */
    public record Junk(ItemStack item, int tier) {
    }

    private final List<Junk> junkPool = new ArrayList<>();
    private final Map<Integer, Double> tierPercent = new LinkedHashMap<>();
    private boolean junkEnabled = true;
    private final java.util.Set<String> bossKeys = new java.util.LinkedHashSet<>();
    private int bossTier = 7;
    private double bossPercent = 1.0;
    private double luckPerPoint = 0.10;
    private double luckMax = 5.0;
    private final Map<String, Integer> guaranteed = new LinkedHashMap<>();

    public int junkCount() {
        return junkPool.size();
    }

    public void setJunkPool(List<Junk> pool) {
        junkPool.clear();
        junkPool.addAll(pool);
    }

    private void configure(FileConfiguration c) {
        junkEnabled = c.getBoolean("drop-rules.cop-drop.enabled", true);
        tierPercent.clear();
        double[] def = {0.01, 0.008, 0.006, 0.004, 0.002, 0.0015, 0.001};
        for (int t = 1; t <= 7; t++) {
            tierPercent.put(t, c.getDouble("drop-rules.cop-drop.tier-percent." + t, def[t - 1]));
        }
        bossKeys.clear();
        List<String> bk = c.getStringList("drop-rules.boss-cop-drop.mobs");
        if (bk.isEmpty()) bk = List.of("crystal", "overlord", "overlord_clone");
        for (String k : bk) bossKeys.add(normalize(k));
        bossTier = c.getInt("drop-rules.boss-cop-drop.only-tier", 7);
        bossPercent = c.getDouble("drop-rules.boss-cop-drop.percent", 1.0);
        luckPerPoint = c.getDouble("drop-rules.luck.per-point", 0.10);
        luckMax = Math.max(1.0, c.getDouble("drop-rules.luck.max-multiplier", 5.0));
        guaranteed.clear();
        guaranteed.put("crystal", 1);
        guaranteed.put("overlord", 1);
        ConfigurationSection g = c.getConfigurationSection("drop-rules.guaranteed");
        if (g != null) {
            for (String k : g.getKeys(false)) {
                guaranteed.put(normalize(k), Math.max(0, g.getInt(k)));
            }
        }
    }

    /** Oyuncunun LUCK ozelligine gore sans carpani (1.0 = bonus yok). */
    public double luckMultiplier(org.bukkit.entity.Player p) {
        if (p == null) return 1.0;
        for (String ad : new String[]{"LUCK", "GENERIC_LUCK"}) {
            try {
                Object a = org.bukkit.attribute.Attribute.class.getField(ad).get(null);
                var inst = p.getAttribute((org.bukkit.attribute.Attribute) a);
                if (inst != null) {
                    return Math.min(luckMax, 1.0 + Math.max(0.0, inst.getValue()) * luckPerPoint);
                }
            } catch (ReflectiveOperationException | RuntimeException ignored) {
                // sonraki ad
            }
        }
        return 1.0;
    }

    public List<ItemStack> roll(String mob) {
        return roll(mob, null);
    }

    private static final org.bukkit.NamespacedKey PREMIUM = new org.bukkit.NamespacedKey("zindan", "drop_premium");

    /** Drop Premium (ZindanSistemi): aktifse tum sanslar 2 kat (%100 artis). */
    public static double premiumCarpan(org.bukkit.entity.Player p) {
        if (p == null) return 1.0;
        Long bitis = p.getPersistentDataContainer().get(PREMIUM, org.bukkit.persistence.PersistentDataType.LONG);
        return bitis != null && bitis > System.currentTimeMillis() ? 2.0 : 1.0;
    }

    /**
     * Ozel kayitlar + (aciksa) ortak cop havuzu icin zar atar. Sans bonusu tum oranlara carpilir.
     * Garantili drop tanimliysa ve hicbir sey dusmediyse agirlikli rastgele bir esya verilir.
     */
    public List<ItemStack> roll(String mob, org.bukkit.entity.Player luckOwner) {
        double mult = luckMultiplier(luckOwner) * premiumCarpan(luckOwner);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        List<ItemStack> won = new ArrayList<>();
        for (Entry e : entries(mob)) {
            if (r.nextDouble() < Math.min(1.0, e.chance() * mult)) {
                won.add(e.item().clone());
            }
        }
        if (junkEnabled) {
            boolean boss = bossKeys.contains(normalize(mob));
            for (Junk j : junkPool) {
                if (boss && j.tier() != bossTier) continue;     // bosslar yalnizca Kadim cop dusurur
                double pct = boss ? bossPercent : tierPercent.getOrDefault(j.tier(), 0.001);
                if (r.nextDouble() < Math.min(1.0, pct / 100.0 * mult)) {
                    won.add(j.item().clone());
                }
            }
        }
        int min = guaranteed.getOrDefault(normalize(mob), 0);
        while (won.size() < min) {
            ItemStack pick = pickGuaranteed(mob, r);
            if (pick == null) break;
            won.add(pick);
        }
        return won;
    }

    private ItemStack pickGuaranteed(String mob, ThreadLocalRandom r) {
        List<Entry> list = entries(mob);
        double total = 0;
        for (Entry e : list) total += Math.max(e.chance(), 1e-9);
        if (total > 0 && !list.isEmpty()) {
            double x = r.nextDouble() * total;
            for (Entry e : list) {
                x -= Math.max(e.chance(), 1e-9);
                if (x <= 0) return e.item().clone();
            }
            return list.get(list.size() - 1).item().clone();
        }
        if (junkEnabled && !junkPool.isEmpty()) {
            boolean boss = bossKeys.contains(normalize(mob));
            List<Junk> cand = new ArrayList<>();
            for (Junk j : junkPool) {
                if (!boss || j.tier() == bossTier) cand.add(j);
            }
            if (!cand.isEmpty()) {
                return cand.get(r.nextInt(cand.size())).item().clone();
            }
        }
        return null;
    }

    // ---- kayit / yukleme ----

    public void load(FileConfiguration config) {
        configure(config);
        tables.clear();
        ConfigurationSection root = config.getConfigurationSection("drops");
        if (root == null) return;

        for (String mob : root.getKeys(false)) {
            List<Entry> list = new ArrayList<>();
            List<?> raw = root.getList(mob);
            if (raw != null) {
                for (Object o : raw) {
                    if (!(o instanceof Map<?, ?> map)) continue;
                    Object item = map.get("item");
                    Object chance = map.get("chance");
                    if (item instanceof ItemStack stack && !stack.getType().isAir()) {
                        double c = chance instanceof Number n ? n.doubleValue() : 1.0;
                        list.add(new Entry(stack, Math.max(0.0, Math.min(1.0, c))));
                    }
                }
            }
            tables.put(normalize(mob), list);
        }
    }

    public void save(FileConfiguration config) {
        config.set("drops", null);
        for (Map.Entry<String, List<Entry>> e : tables.entrySet()) {
            List<Map<String, Object>> out = new ArrayList<>();
            for (Entry entry : e.getValue()) {
                out.add(entry.toMap());
            }
            config.set("drops." + e.getKey(), out);
        }
    }
}
