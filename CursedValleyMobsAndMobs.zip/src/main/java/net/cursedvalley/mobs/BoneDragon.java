package net.cursedvalley.mobs;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.Slime;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.BiConsumer;

/**
 * Bone Dragon -- 50.000 canli iskelet ejder bossu.
 *
 * Gorunum: 14 kemikli bir ItemDisplay iskeleti (model: cursedvalley:bone_dragon/*).
 * Her kemik, kupleri tek tek donduren "composite" bir esya modelidir; kemikler
 * burada ileri kinematikle (FK) hareket ettirilir. Ucus/saldiri yapay zekasi
 * tamamen bu sinifta; vanilla Ender Dragon'la hicbir ilgisi yoktur.
 *
 * Vurulabilir govde: gorunmez, yercekimsiz, yapay zekasi kapali buyuk bir Slime.
 * Can BossState'te elle tutulur (hasar olaylari ana sinifta iptal edilip buraya gelir).
 */
public final class BoneDragon {

    private enum Mode { CIRCLE, BREATH, SWOOP, RAIN, GUST, SCREECH, SUMMON, LAND, DYING }

    private static final String[] NAMES = BoneDragonRig.NAMES;
    private static final int NB = NAMES.length;
    private static final int BODY = 0, NECK = 1, HEAD = 2, JAW = 3, WR1 = 4, WR2 = 5, WL1 = 6, WL2 = 7, TAIL0 = 8;

    private static final class Mark {
        final Location at; int t; final double r; final double dmg;
        Mark(Location at, int t, double r, double dmg) { this.at = at; this.t = t; this.r = r; this.dmg = dmg; }
    }

    private final JavaPlugin plugin;
    private final String tag;
    private final List<ItemDisplay> parts = new ArrayList<>();
    private final List<Mark> marks = new ArrayList<>();
    private final List<Skeleton> minions = new ArrayList<>();
    private final ArrayDeque<Mode> queue = new ArrayDeque<>();
    private final Set<UUID> hitSet = new HashSet<>();

    private Slime hit;
    private BossState state;
    private World world;
    private Location home;
    private BiConsumer<List<UUID>, Location> deathHandler;

    // ---- kinematik ----
    private final Vector pos = new Vector();
    private double hd, pitch, roll, speed;
    private Mode mode = Mode.CIRCLE;
    private int tick, st, stage, st2, cooldown, attackCount, phase;
    private Player target;
    private double orbitDir = 1;
    private Vector diveTarget;
    private double groundCache;
    private int idleSeconds;

    // ---- animasyon ----
    private double wingPhase, wingBase = 28, wingAmp = 24, wingSpeed = 0.22;
    private double jawOpen, jawGoal, neckBob, tailKick;
    private int tailSwing;
    private double hitBoxH = 5.7;
    private int groundAttackCd, groundRoarCd;

    public BoneDragon(JavaPlugin plugin, String tag) {
        this.plugin = plugin;
        this.tag = tag;
    }

    public void setDeathHandler(BiConsumer<List<UUID>, Location> h) { this.deathHandler = h; }

    // ==================== AYARLAR ====================

    private double cfg(String key, double def) { return plugin.getConfig().getDouble("bone-dragon." + key, def); }
    private int cfgI(String key, int def) { return plugin.getConfig().getInt("bone-dragon." + key, def); }
    private double scale() { return cfg("scale", 2.2); }

    // ---- kase (bowl) siniri: ejder bu daireden cikamaz ----
    private double arenaX() { return cfg("arena-x", plugin.getConfig().getDouble("crystal.x", 0)); }
    private double arenaZ() { return cfg("arena-z", plugin.getConfig().getDouble("crystal.z", 0)); }
    private double arenaR() { return cfg("arena-radius", 50); }

    /** Yatay konumu daire icine ceker. */
    private void clampArena(Vector v) {
        double dx = v.getX() - arenaX(), dz = v.getZ() - arenaZ();
        double d = Math.hypot(dx, dz), r = arenaR();
        if (d > r) { v.setX(arenaX() + dx / d * r); v.setZ(arenaZ() + dz / d * r); }
    }
    private boolean inArena(Location l, double extra) {
        return Math.hypot(l.getX() - arenaX(), l.getZ() - arenaZ()) <= arenaR() + extra;
    }
    private double enrage() { return 1.0 + 0.12 * phase; }

    // ==================== DURUM ====================

    public boolean isAlive() { return hit != null && !hit.isDead(); }
    public boolean isBody(Entity e) { return hit != null && e != null && e.getUniqueId().equals(hit.getUniqueId()); }
    public Entity body() { return hit; }
    public BossState state() { return state; }

    public boolean isMinion(Entity e) {
        return e != null && e.getScoreboardTags().contains(MINION_TAG);
    }
    public static final String MINION_TAG = "cv_dragon_minion";

    // ==================== DOGUS / KALDIRMA ====================

    public boolean spawn(Location loc) {
        if (isAlive()) return false;
        world = loc.getWorld();
        if (world == null) return false;
        Vector sp = loc.toVector();
        clampArena(sp);
        // kristalin yakininda dogmaz: bolgenin disina itilir
        double cx = plugin.getConfig().getDouble("crystal.x", 0), cz = plugin.getConfig().getDouble("crystal.z", 0);
        double avoid = cfg("spawn-avoid-crystal-radius", 20);
        double ddx = sp.getX() - cx, ddz = sp.getZ() - cz, dd = Math.hypot(ddx, ddz);
        if (dd < avoid) {
            if (dd < 1e-3) { ddx = 1; ddz = 0; dd = 1; }
            sp.setX(cx + ddx / dd * avoid);
            sp.setZ(cz + ddz / dd * avoid);
            clampArena(sp);
        }
        loc = new Location(world, sp.getX(), loc.getY(), sp.getZ());
        home = loc.clone();
        double hp = Math.max(100, cfg("max-health", 50000));
        state = new BossState("BONE DRAGON", hp, true);

        pos.setX(loc.getX()); pos.setY(loc.getY()); pos.setZ(loc.getZ());
        hd = 0; pitch = 0; roll = 0; speed = 0.4;
        mode = Mode.CIRCLE; st = 0; stage = 0; phase = 0; attackCount = 0;
        cooldown = 100; queue.clear(); marks.clear(); hitSet.clear(); jawOpen = 0; tick = 0;

        int size = Math.max(2, cfgI("hitbox-size", 11));
        hit = (Slime) world.spawnEntity(loc.clone().add(0, -3, 0), org.bukkit.entity.EntityType.SLIME);
        hit.setSize(size);
        hitBoxH = 0.52 * size;
        hit.addScoreboardTag(tag);
        hit.setAI(false);
        hit.setGravity(false);
        hit.setSilent(true);
        hit.setInvisible(true);
        hit.setCollidable(false);
        hit.setPersistent(true);
        hit.setRemoveWhenFarAway(false);
        hit.setCustomNameVisible(true);
        hit.customName(state.bar());
        var mh = hit.getAttribute(Attribute.MAX_HEALTH);
        if (mh != null) { mh.setBaseValue(Math.min(1024, mh.getBaseValue())); }

        Transformation[] tr = pose();
        for (int i = 0; i < NB; i++) {
            final int bi = i;
            ItemStack it = new ItemStack(Material.PAPER);
            ItemMeta meta = it.getItemMeta();
            meta.setItemModel(new NamespacedKey("cursedvalley", "bone_dragon/" + NAMES[i]));
            it.setItemMeta(meta);
            ItemDisplay d = world.spawn(loc, ItemDisplay.class, e -> {
                e.setItemStack(it);
                e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                e.setBillboard(Display.Billboard.FIXED);
                e.setViewRange(4.0f);
                e.setDisplayWidth(60f);
                e.setDisplayHeight(60f);
                e.setBrightness(new Display.Brightness(15, 15));
                e.setPersistent(false);
                e.setInterpolationDuration(0);
                e.setTeleportDuration(0);
                e.setTransformation(tr[bi]);
                e.addScoreboardTag(tag);
            });
            parts.add(d);
        }
        sfx(loc, Sound.ENTITY_WITHER_SPAWN, 3.0f, 0.5f);
        sfx(loc, Sound.ENTITY_RAVAGER_ROAR, 3.0f, 0.3f);
        Bukkit.broadcast(Component.text("Bone Dragon uyandı!", NamedTextColor.DARK_RED));
        return true;
    }

    public void remove() {
        for (ItemDisplay d : parts) if (d != null && !d.isDead()) d.remove();
        parts.clear();
        if (hit != null && !hit.isDead()) hit.remove();
        hit = null;
        for (Skeleton s : minions) if (s != null && !s.isDead()) s.remove();
        minions.clear();
        marks.clear();
        state = null;
    }

    // ==================== HASAR ====================

    /** Oyuncu vurusu. Olunce olum animasyonu baslar. */
    public void damage(Player attacker, double dmg) {
        if (!isAlive() || state == null || mode == Mode.DYING) return;
        if (state.hit(attacker, dmg)) {
            startDying();
            return;
        }
        hit.customName(state.bar());
        if (tick % 5 == 0) sfx(hit.getLocation(), Sound.ENTITY_SKELETON_HURT, 1.6f, 0.45f);
        int ph = state.takePhase();
        if (ph > 0) {
            phase++;
            queue.clear();
            queue.add(Mode.SCREECH);
            queue.add(Mode.SUMMON);
            queue.add(Mode.LAND);
            Bukkit.broadcast(Component.text("Bone Dragon öfkelendi! (%" + ph + ")", NamedTextColor.RED));
        }
    }

    private void startDying() {
        mode = Mode.DYING;
        st = 0;
        marks.clear();
        for (Skeleton s : minions) if (s != null && !s.isDead()) s.remove();
        minions.clear();
        hit.customName(Component.text("Bone Dragon", NamedTextColor.GRAY));
        sfx(pos(), Sound.ENTITY_WITHER_DEATH, 3.0f, 0.5f);
        sfx(pos(), Sound.ENTITY_RAVAGER_DEATH, 3.0f, 0.35f);
    }

    private void finish() {
        Location at = pos();
        List<UUID> hitters = new ArrayList<>(state.attackers().keySet());
        world.spawnParticle(Particle.EXPLOSION_EMITTER, at, 6, 3, 2, 3, 0);
        sfx(at, Sound.ENTITY_GENERIC_EXPLODE, 3.0f, 0.6f);
        remove();
        if (deathHandler != null) deathHandler.accept(hitters, at);
    }

    // ==================== ANA DONGU ====================

    public void tick() {
        if (hit == null) return;
        if (hit.isDead() || world == null) { remove(); return; }
        tick++;
        st++;

        if (tick % 10 == 0) groundCache = groundY(pos.getX(), pos.getZ());

        switch (mode) {
            case CIRCLE -> tickCircle();
            case BREATH -> tickBreath();
            case SWOOP -> tickSwoop();
            case RAIN -> tickRain();
            case GUST -> tickGust();
            case SCREECH -> tickScreech();
            case SUMMON -> tickSummon();
            case LAND -> tickLand();
            case DYING -> tickDying();
        }
        clampArena(pos);
        tickMarks();
        animate();

        // vurulabilir govde: merkezine hizali
        hit.teleport(new Location(world, pos.getX(), pos.getY() - hitBoxH / 2.0, pos.getZ()));

        if (tick % 2 == 0) pushVisuals();
        if (tick % 20 == 0) everySecond();
    }

    private void everySecond() {
        if (state == null) return;
        if (mode != Mode.DYING) hit.customName(state.bar());
        minions.removeIf(s -> s == null || s.isDead());

        boolean near = false;
        for (Player p : world.getPlayers()) {
            if (valid(p) && p.getLocation().distanceSquared(pos()) < 140 * 140) { near = true; break; }
        }
        if (near) idleSeconds = 0;
        else if (++idleSeconds >= 30 && mode != Mode.DYING) {
            // kimse yok: can dolar, eve doner
            state.healFull();
            idleSeconds = 0;
        }
        if (mode == Mode.CIRCLE || mode == Mode.LAND) {
            state.heal(cfg("regen-per-second", 40) * (near ? 1 : 25));
        }
    }

    // ==================== YARDIMCILAR ====================

    private Location pos() { return new Location(world, pos.getX(), pos.getY(), pos.getZ()); }

    private boolean valid(Player p) {
        return p != null && p.isOnline() && !p.isDead() && p.getWorld().equals(world)
                && p.getGameMode() != GameMode.SPECTATOR && p.getGameMode() != GameMode.CREATIVE;
    }

    private Player nearestPlayer(double max) {
        Player best = null; double bd = max * max;
        for (Player p : world.getPlayers()) {
            if (!valid(p) || !inArena(p.getLocation(), 15)) continue;
            double d = p.getLocation().distanceSquared(pos());
            if (d < bd) { bd = d; best = p; }
        }
        return best;
    }

    private Player randomPlayer(double max) {
        List<Player> l = new ArrayList<>();
        for (Player p : world.getPlayers()) {
            if (valid(p) && inArena(p.getLocation(), 15) && p.getLocation().distanceSquared(pos()) < max * max) l.add(p);
        }
        return l.isEmpty() ? null : l.get(ThreadLocalRandom.current().nextInt(l.size()));
    }

    private double groundY(double x, double z) {
        return world.getHighestBlockYAt((int) Math.floor(x), (int) Math.floor(z)) + 1.0;
    }

    /** Govde merkezinin yerden yuksekligi (ayaklar yere degince). */
    private double footCenter() { return 1.45 * scale(); }

    private static double wrap(double a) {
        while (a > Math.PI) a -= 2 * Math.PI;
        while (a < -Math.PI) a += 2 * Math.PI;
        return a;
    }
    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }

    private void sfx(Location at, Sound s, float vol, float pitch) {
        at.getWorld().playSound(at, s, SoundCategory.HOSTILE, vol, pitch);
    }

    private Vector forward() {
        return new Vector(Math.cos(hd) * Math.cos(pitch), Math.sin(pitch), Math.sin(hd) * Math.cos(pitch));
    }

    /** Agzin ucunun dunya konumu. */
    private Vector headPos() {
        Quaternionf q = bodyRot();
        Vector3f v = new Vector3f(-3.95f - BoneDragonRig.CENTER[0], 2.3f - BoneDragonRig.CENTER[1], 0f)
                .mul((float) scale());
        q.transform(v);
        return new Vector(pos.getX() + v.x, pos.getY() + v.y, pos.getZ() + v.z);
    }

    private void hurt(Player p, double dmg) {
        if (!valid(p)) return;
        p.damage(dmg, hit);
    }

    private void push(Player p, Vector dir, double h, double y) {
        Vector d = dir.clone().setY(0);
        if (d.lengthSquared() < 1e-6) d = new Vector(1, 0, 0);
        d.normalize().multiply(h).setY(y);
        p.setVelocity(d);
    }

    /** Verilen noktaya yonelir ve hareket eder. */
    private void steer(double tx, double ty, double tz, double spd, double turn) {
        Vector tv = new Vector(tx, ty, tz);
        clampArena(tv);
        tx = tv.getX(); tz = tv.getZ();
        double dx = tx - pos.getX(), dy = ty - pos.getY(), dz = tz - pos.getZ();
        double hz = Math.hypot(dx, dz);
        if (hz > 0.5) {
            double diff = wrap(Math.atan2(dz, dx) - hd);
            double step = clamp(diff, -turn, turn);
            hd += step;
            roll += (clamp(-step * 16, -0.5, 0.5) - roll) * 0.1;
        } else {
            roll *= 0.9;
        }
        double wp = clamp(Math.atan2(dy, Math.max(hz, 1e-3)), -0.75, 0.75);
        pitch += clamp(wp - pitch, -0.04, 0.04);
        speed += (spd - speed) * 0.08;
        pos.add(new Vector(Math.cos(hd) * Math.cos(pitch) * speed, Math.sin(pitch) * speed,
                Math.sin(hd) * Math.cos(pitch) * speed));
    }

    /** Konumunu degistirmeden hedefe doner (nefes, ciglik). */
    private void faceTo(Vector at, double turn) {
        double dx = at.getX() - pos.getX(), dy = at.getY() - pos.getY(), dz = at.getZ() - pos.getZ();
        hd += clamp(wrap(Math.atan2(dz, dx) - hd), -turn, turn);
        double wp = clamp(Math.atan2(dy, Math.max(Math.hypot(dx, dz), 1e-3)), -0.6, 0.6);
        pitch += clamp(wp - pitch, -0.03, 0.03);
        roll *= 0.9;
        speed *= 0.9;
    }

    private void hover(double y) {
        pos.setY(pos.getY() + (y - pos.getY()) * 0.04 + Math.sin(tick * 0.1) * 0.02);
    }

    private void enter(Mode m) {
        mode = m; st = 0; stage = 0; st2 = 0;
        hitSet.clear();
    }

    private void endAttack(int baseCooldownTicks) {
        mode = Mode.CIRCLE; st = 0; stage = 0;
        cooldown = (int) (baseCooldownTicks / enrage());
        jawGoal = 0;
    }

    // ==================== DAIRE (bekleme / hazirlik) ====================

    private Vector orbitCenter() {
        Player p = nearestPlayer(cfg("leash", 130));
        if (p != null) return p.getLocation().toVector();
        return home.toVector();
    }

    private void orbit(double spdMul) {
        Vector c = orbitCenter();
        clampArena(c);
        double r = Math.min(cfg("orbit-radius", 28), arenaR() * 0.6);
        double a = Math.atan2(pos.getZ() - c.getZ(), pos.getX() - c.getX());
        double ahead = a + 0.5 * orbitDir;
        double tx = c.getX() + Math.cos(ahead) * r, tz = c.getZ() + Math.sin(ahead) * r;
        double ty = Math.max(groundY(c.getX(), c.getZ()), c.getY()) + cfg("hover-height", 14);
        // yerden cok uzaksa da dengeli
        steer(tx, ty, tz, cfg("speed", 0.75) * enrage() * spdMul, 0.055);
    }

    private void tickCircle() {
        setWings(28, 24, 0.22);
        jawGoal = 0;
        orbit(1.0);
        if (--cooldown > 0) return;
        Player t = nearestPlayer(cfg("leash", 130));
        if (t == null) { cooldown = 40; return; }
        target = t;
        if (!queue.isEmpty()) { enter(queue.poll()); return; }
        attackCount++;
        if (attackCount % Math.max(2, cfgI("land-every", 4)) == 0) { enter(Mode.LAND); return; }
        List<Mode> pool = new ArrayList<>(List.of(Mode.BREATH, Mode.SWOOP, Mode.RAIN, Mode.GUST));
        if (phase >= 1 && minions.size() < 2) pool.add(Mode.SUMMON);
        Mode pick = pool.get(ThreadLocalRandom.current().nextInt(pool.size()));
        enter(pick);
    }

    // ==================== KEMIK NEFESI ====================

    private void tickBreath() {
        Player t = target;
        if (!valid(t) || st > 200) { endAttack(90); return; }
        setWings(30, 12, 0.3);
        Vector tp = t.getLocation().toVector().add(new Vector(0, 1, 0));
        if (st < 55) {                                   // sarj
            // hedefe dogru yaklas, cok yakinsa havada dur
            double dist = tp.distance(pos);
            if (dist > 30) steer(tp.getX(), tp.getY() + 6, tp.getZ(), 0.5, 0.05); else faceTo(tp, 0.06);
            jawGoal = 35;
            if (st == 2) sfx(pos(), Sound.ENTITY_WARDEN_ROAR, 2.5f, 0.55f);
            Vector hp = headPos();
            world.spawnParticle(Particle.SOUL_FIRE_FLAME, hp.getX(), hp.getY(), hp.getZ(), 6, 0.6, 0.6, 0.6, 0.04);
            return;
        }
        // nefes
        faceTo(tp, 0.025);
        jawGoal = 40;
        hover(Math.max(pos.getY(), groundY(pos.getX(), pos.getZ()) + 8));
        Vector from = headPos();
        Vector dir = forward();
        double len = cfg("breath-range", 30);
        for (double d = 1; d < len; d += 1.6) {
            Vector p = from.clone().add(dir.clone().multiply(d));
            double w = 0.3 + d * 0.06;
            world.spawnParticle(Particle.SOUL_FIRE_FLAME, p.getX(), p.getY(), p.getZ(), 2, w, w, w, 0.01);
            if ((int) (d * 10) % 3 == 0)
                world.spawnParticle(Particle.ITEM, p.getX(), p.getY(), p.getZ(), 2, w, w, w, 0.02,
                        new ItemStack(Material.BONE_MEAL));
        }
        if (st % 12 == 0) sfx(pos(), Sound.ENTITY_BLAZE_SHOOT, 1.8f, 0.5f);
        if (st % 5 == 0) {
            double dmg = cfg("breath-damage", 14) * enrage();
            for (Player p : world.getPlayers()) {
                if (!valid(p)) continue;
                Vector pv = p.getLocation().toVector().add(new Vector(0, 1, 0));
                double along = pv.clone().subtract(from).dot(dir);
                if (along < 0 || along > len) continue;
                double off = from.clone().add(dir.clone().multiply(along)).distance(pv);
                if (off <= 1.8 + along * 0.06) {
                    hurt(p, dmg);
                    p.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 60, 0, false, true));
                }
            }
        }
        if (st >= 125) endAttack(100);
    }

    // ==================== DALIS ====================

    private void tickSwoop() {
        Player t = target;
        if (!valid(t)) { endAttack(80); return; }
        Vector tp = t.getLocation().toVector();
        if (stage == 0) {                                       // yuksel ve hizalan
            setWings(28, 26, 0.26);
            steer(tp.getX() + Math.cos(hd) * 22, tp.getY() + 18, tp.getZ() + Math.sin(hd) * 22, 0.9, 0.07);
            if (st >= 50) {
                stage = 1; st2 = 0;
                diveTarget = tp.clone().add(new Vector(0, 1.2, 0));
                sfx(pos(), Sound.ENTITY_RAVAGER_ROAR, 3.0f, 0.5f);
                jawGoal = 40;
            }
        } else if (stage == 1) {                                // dalis
            st2++;
            setWings(-25, 3, 0.1);
            steer(diveTarget.getX(), diveTarget.getY(), diveTarget.getZ(), 1.6 * enrage(), 0.14);
            double dmg = cfg("swoop-damage", 22) * enrage();
            for (Player p : world.getPlayers()) {
                if (!valid(p) || hitSet.contains(p.getUniqueId())) continue;
                if (p.getLocation().add(0, 1, 0).distanceSquared(pos()) < 6.5 * 6.5) {
                    hitSet.add(p.getUniqueId());
                    hurt(p, dmg);
                    push(p, forward(), 1.5, 0.7);
                }
            }
            world.spawnParticle(Particle.CLOUD, pos().getX(), pos().getY(), pos().getZ(), 8, 1.5, 1, 1.5, 0.02);
            if (pos.distance(diveTarget) < 4.5 || st2 > 70 || pos.getY() <= groundCache + footCenter() * 0.8) {
                stage = 2; st2 = 0;
                Location g = pos();
                world.spawnParticle(Particle.EXPLOSION, g, 3, 1.5, 0.3, 1.5, 0);
                sfx(g, Sound.ENTITY_GENERIC_EXPLODE, 1.6f, 0.7f);
                jawGoal = 0;
            }
        } else {                                                // yuksel
            st2++;
            setWings(30, 28, 0.28);
            Vector f = forward();
            steer(pos.getX() + f.getX() * 40, groundCache + cfg("hover-height", 14), pos.getZ() + f.getZ() * 40,
                    1.0, 0.04);
            if (st2 > 45) endAttack(90);
        }
    }

    // ==================== KEMIK YAGMURU ====================

    private void tickRain() {
        setWings(28, 20, 0.22);
        orbit(0.8);
        if (st == 1) sfx(pos(), Sound.ENTITY_WITHER_AMBIENT, 2.5f, 0.5f);
        if (st < 110 && st % 5 == 0) {
            Player p = randomPlayer(cfg("leash", 130));
            if (p != null) {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                Location at = p.getLocation().add(r.nextDouble(-4, 4), 0, r.nextDouble(-4, 4));
                at.setY(groundY(at.getX(), at.getZ()));
                marks.add(new Mark(at, 32, 3.2, cfg("rain-damage", 16) * enrage()));
            }
        }
        if (st >= 140) endAttack(80);
    }

    private void tickMarks() {
        if (marks.isEmpty()) return;
        var it = marks.iterator();
        while (it.hasNext()) {
            Mark m = it.next();
            m.t--;
            Location c = m.at;
            if (m.t > 0) {
                if (m.t % 3 == 0) {
                    double rr = m.r * (1.0 - m.t / 40.0 * 0.15);
                    for (int i = 0; i < 16; i++) {
                        double a = i * Math.PI / 8;
                        world.spawnParticle(Particle.DUST, c.getX() + Math.cos(a) * rr, c.getY() + 0.1,
                                c.getZ() + Math.sin(a) * rr, 1, 0, 0, 0, 0,
                                new Particle.DustOptions(Color.fromRGB(235, 235, 210), 1.3f));
                    }
                }
            } else {
                world.spawnParticle(Particle.ITEM, c.getX(), c.getY() + 1, c.getZ(), 40, m.r * 0.4, 1.2, m.r * 0.4, 0.15,
                        new ItemStack(Material.BONE));
                world.spawnParticle(Particle.EXPLOSION, c.getX(), c.getY() + 0.5, c.getZ(), 1, 0, 0, 0, 0);
                sfx(c, Sound.ENTITY_SKELETON_SHOOT, 1.4f, 0.5f);
                sfx(c, Sound.BLOCK_BONE_BLOCK_BREAK, 1.8f, 0.6f);
                for (Player p : world.getPlayers()) {
                    if (!valid(p)) continue;
                    if (p.getLocation().distanceSquared(c) < m.r * m.r) {
                        hurt(p, m.dmg);
                        p.setVelocity(new Vector(0, 0.8, 0));
                    }
                }
                it.remove();
            }
        }
    }

    // ==================== KANAT FIRTINASI ====================

    private void tickGust() {
        Player t = target;
        if (!valid(t)) { endAttack(80); return; }
        Vector tp = t.getLocation().toVector();
        if (st < 35) {
            setWings(35, 38, 0.5);
            steer(tp.getX(), Math.max(tp.getY(), groundCache) + 9, tp.getZ(), 0.6, 0.08);
            if (st % 6 == 0) sfx(pos(), Sound.ENTITY_PHANTOM_FLAP, 2.0f, 0.5f);
            return;
        }
        if (st == 35) {
            Location c = pos();
            sfx(c, Sound.ENTITY_BREEZE_WIND_CHARGE_BURST, 3.0f, 0.5f);
            sfx(c, Sound.ENTITY_RAVAGER_ROAR, 2.0f, 0.5f);
            double dmg = cfg("gust-damage", 8) * enrage();
            for (Player p : world.getPlayers()) {
                if (!valid(p)) continue;
                double d = p.getLocation().distance(c);
                if (d > 26) continue;
                hurt(p, dmg);
                push(p, p.getLocation().toVector().subtract(c.toVector()), 1.7, 0.7);
                p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1, false, true));
            }
            for (int i = 0; i < 40; i++) {
                double a = i * Math.PI / 20;
                world.spawnParticle(Particle.CLOUD, c.getX() + Math.cos(a) * 3, c.getY() - 5, c.getZ() + Math.sin(a) * 3,
                        0, Math.cos(a), 0.05, Math.sin(a), 1.0);
            }
        }
        setWings(30, 20, 0.3);
        steer(pos.getX() + Math.cos(hd) * 10, pos.getY(), pos.getZ() + Math.sin(hd) * 10, 0.4, 0.05);
        if (st >= 60) endAttack(80);
    }

    // ==================== CIGLIK ====================

    private void tickScreech() {
        setWings(30, 10, 0.3);
        faceTo(pos.clone().add(forward().multiply(10)), 0.01);
        jawGoal = 40;
        if (st == 2) sfx(pos(), Sound.ENTITY_WARDEN_ROAR, 3.5f, 0.45f);
        if (st == 20) {
            Location c = pos();
            sfx(c, Sound.ENTITY_WITHER_DEATH, 3.0f, 0.4f);
            double dmg = cfg("screech-damage", 12);
            for (Player p : world.getPlayers()) {
                if (!valid(p) || p.getLocation().distanceSquared(c) > 50 * 50) continue;
                hurt(p, dmg);
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0, false, true));
                push(p, p.getLocation().toVector().subtract(c.toVector()), 0.9, 0.4);
            }
            for (int i = 0; i < 48; i++) {
                double a = i * Math.PI / 24;
                world.spawnParticle(Particle.SOUL, c.getX(), c.getY(), c.getZ(), 0, Math.cos(a), 0, Math.sin(a), 1.2);
            }
        }
        if (st >= 45) endAttack(40);
    }

    // ==================== KEMIK ASKERI ====================

    private void tickSummon() {
        setWings(30, 14, 0.28);
        jawGoal = 25;
        orbit(0.5);
        if (st == 20) {
            sfx(pos(), Sound.ENTITY_EVOKER_PREPARE_SUMMON, 3.0f, 0.5f);
            int want = cfgI("minion-count", 4);
            int cap = cfgI("minion-cap", 8);
            for (int i = 0; i < want && minions.size() < cap; i++) {
                Player p = randomPlayer(cfg("leash", 130));
                if (p == null) break;
                ThreadLocalRandom r = ThreadLocalRandom.current();
                Location at = p.getLocation().add(r.nextDouble(-8, 8), 0, r.nextDouble(-8, 8));
                at.setY(groundY(at.getX(), at.getZ()));
                Skeleton s = world.spawn(at, Skeleton.class, e -> {
                    e.customName(Component.text("Kemik Askeri", NamedTextColor.GRAY));
                    e.setCustomNameVisible(true);
                    e.addScoreboardTag(tag);
                    e.addScoreboardTag(MINION_TAG);
                    e.setRemoveWhenFarAway(true);
                    e.getEquipment().setItemInMainHand(new ItemStack(Material.BOW));
                    var mh = e.getAttribute(Attribute.MAX_HEALTH);
                    double hp = cfg("minion-health", 60);
                    if (mh != null) { mh.setBaseValue(hp); e.setHealth(hp); }
                });
                world.spawnParticle(Particle.SOUL, at.getX(), at.getY() + 1, at.getZ(), 25, 0.4, 0.8, 0.4, 0.05);
                minions.add(s);
            }
        }
        if (st >= 50) endAttack(70);
    }

    // ==================== INIS / YAKIN DOVUS ====================

    private void tickLand() {
        Player t = valid(target) ? target : nearestPlayer(cfg("leash", 130));
        if (t == null) { endAttack(60); return; }
        target = t;
        Vector tp = t.getLocation().toVector();
        if (stage == 0) {                                       // alana yaklas
            setWings(28, 22, 0.24);
            Vector away = pos.clone().subtract(tp).setY(0);
            if (away.lengthSquared() < 1e-6) away = new Vector(1, 0, 0);
            away.normalize().multiply(14);
            double lx = tp.getX() + away.getX(), lz = tp.getZ() + away.getZ();
            double floor = groundY(lx, lz) + footCenter();
            steer(lx, Math.max(floor + 4, groundY(lx, lz) + 6), lz, 0.8, 0.07);
            if (Math.hypot(lx - pos.getX(), lz - pos.getZ()) < 9 || st > 160) { stage = 1; st2 = 0; }
        } else if (stage == 1) {                                // alcal
            st2++;
            setWings(20, 18, 0.2);
            double floor = groundCache + footCenter();
            steer(pos.getX() + Math.cos(hd) * 5, floor, pos.getZ() + Math.sin(hd) * 5, 0.35, 0.05);
            if (pos.getY() <= floor + 0.4 || st2 > 120) {
                stage = 2; st2 = 0; groundAttackCd = 30; groundRoarCd = 80;
                pos.setY(Math.max(pos.getY(), floor));
                sfx(pos(), Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.5f);
                world.spawnParticle(Particle.EXPLOSION, pos().add(0, -footCenter() + 0.5, 0), 6, 3, 0.2, 3, 0);
                for (Player p : world.getPlayers()) {
                    if (valid(p) && p.getLocation().distanceSquared(pos()) < 12 * 12) {
                        push(p, p.getLocation().toVector().subtract(pos), 0.9, 0.5);
                    }
                }
            }
        } else if (stage == 2) {                                // yerde
            st2++;
            setWings(-18, 3, 0.08);
            double floor = groundCache + footCenter();
            pos.setY(floor);
            pitch *= 0.8; roll *= 0.8;
            Vector hp = headPos();
            double dist = Math.hypot(tp.getX() - pos.getX(), tp.getZ() - pos.getZ());
            double want = Math.atan2(tp.getZ() - pos.getZ(), tp.getX() - pos.getX());
            hd += clamp(wrap(want - hd), -0.05, 0.05);
            double stride = dist > 9 ? 0.16 : 0.0;
            pos.add(new Vector(Math.cos(hd) * stride, 0, Math.sin(hd) * stride));
            if (stride > 0 && st2 % 10 == 0) sfx(pos(), Sound.ENTITY_IRON_GOLEM_STEP, 2.0f, 0.5f);
            jawGoal = 0;

            if (groundAttackCd > 0) groundAttackCd--;
            if (groundRoarCd > 0) groundRoarCd--;
            if (groundAttackCd == 0) {
                boolean biteRange = false, sweepRange = false;
                for (Player p : world.getPlayers()) {
                    if (!valid(p)) continue;
                    if (p.getLocation().add(0, 1, 0).distanceSquared(hp.toLocation(world)) < 7 * 7) biteRange = true;
                    if (p.getLocation().distanceSquared(pos()) < 11 * 11) sweepRange = true;
                }
                if (biteRange) {
                    groundAttackCd = 36;
                    jawGoal = 42;
                    sfx(pos(), Sound.ENTITY_RAVAGER_ATTACK, 2.0f, 0.5f);
                    double dmg = cfg("bite-damage", 26) * enrage();
                    for (Player p : world.getPlayers()) {
                        if (valid(p) && p.getLocation().add(0, 1, 0).distanceSquared(hp.toLocation(world)) < 7 * 7) {
                            hurt(p, dmg);
                            push(p, forward(), 1.0, 0.4);
                        }
                    }
                    world.spawnParticle(Particle.SWEEP_ATTACK, hp.getX(), hp.getY(), hp.getZ(), 4, 1.5, 1, 1.5, 0);
                } else if (sweepRange) {
                    groundAttackCd = 40;
                    tailSwing = 20;
                    sfx(pos(), Sound.ITEM_MACE_SMASH_GROUND, 2.0f, 0.5f);
                    double dmg = cfg("claw-damage", 20) * enrage();
                    for (Player p : world.getPlayers()) {
                        if (valid(p) && p.getLocation().distanceSquared(pos()) < 11 * 11) {
                            hurt(p, dmg);
                            push(p, p.getLocation().toVector().subtract(pos), 1.3, 0.5);
                        }
                    }
                    for (int i = 0; i < 24; i++) {
                        double a = i * Math.PI / 12;
                        world.spawnParticle(Particle.SWEEP_ATTACK, pos().getX() + Math.cos(a) * 8, pos().getY() - footCenter() + 1,
                                pos().getZ() + Math.sin(a) * 8, 1, 0, 0, 0, 0);
                    }
                }
            }
            if (groundRoarCd == 0) {
                groundRoarCd = 110;
                jawGoal = 40;
                Location c = pos();
                sfx(c, Sound.ENTITY_WARDEN_ROAR, 3.0f, 0.5f);
                double dmg = cfg("roar-damage", 10);
                for (Player p : world.getPlayers()) {
                    if (valid(p) && p.getLocation().distanceSquared(c) < 18 * 18) {
                        hurt(p, dmg);
                        push(p, p.getLocation().toVector().subtract(c.toVector()), 1.5, 0.6);
                    }
                }
            }
            if (st2 >= cfgI("land-seconds", 12) * 20) { stage = 3; st2 = 0; sfx(pos(), Sound.ENTITY_PHANTOM_FLAP, 3.0f, 0.4f); }
        } else {                                                // havalan
            st2++;
            setWings(32, 30, 0.3);
            Vector f = forward();
            steer(pos.getX() + f.getX() * 20, groundCache + cfg("hover-height", 14), pos.getZ() + f.getZ() * 20, 0.7, 0.04);
            if (st2 > 70) endAttack(70);
        }
    }

    // ==================== OLUM ====================

    private void tickDying() {
        setWings(-20, 10, 0.3);
        jawGoal = 40;
        hd += 0.04;
        pitch += (0.5 - pitch) * 0.05;
        double floor = groundCache + footCenter();
        if (pos.getY() > floor) pos.setY(Math.max(floor, pos.getY() - 0.12));
        roll = Math.sin(tick * 0.9) * 0.15;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (st % 4 == 0) {
            world.spawnParticle(Particle.EXPLOSION, pos.getX() + r.nextDouble(-5, 5), pos.getY() + r.nextDouble(-2, 3),
                    pos.getZ() + r.nextDouble(-5, 5), 1, 0, 0, 0, 0);
            world.spawnParticle(Particle.ITEM, pos.getX(), pos.getY(), pos.getZ(), 12, 3, 2, 3, 0.1,
                    new ItemStack(Material.BONE));
        }
        if (st % 15 == 0) sfx(pos(), Sound.ENTITY_SKELETON_DEATH, 2.5f, 0.4f);
        if (st >= 110) finish();
    }

    // ==================== ANIMASYON ====================

    private void setWings(double base, double amp, double spd) {
        wingBase += (base - wingBase) * 0.1;
        wingAmp += (amp - wingAmp) * 0.1;
        wingSpeed += (spd - wingSpeed) * 0.1;
    }

    private Quaternionf bodyRot() {
        return new Quaternionf().rotateY((float) (Math.PI - hd)).rotateZ((float) -pitch).rotateX((float) roll);
    }

    private void animate() {
        wingPhase += wingSpeed;
        jawOpen += (jawGoal - jawOpen) * 0.2;
        if (tailSwing > 0) tailSwing--;
        tailKick = tailSwing > 0 ? Math.sin(tailSwing / 20.0 * Math.PI) * 45 : 0;
        neckBob = Math.sin(wingPhase * 0.5) * 4;
    }

    /** Kemik donusleri (FK): her kemik icin yerel quaternion. */
    private Quaternionf[] localRots() {
        Quaternionf[] q = new Quaternionf[NB];
        for (int i = 0; i < NB; i++) q[i] = new Quaternionf();
        double s = Math.sin(wingPhase), s2 = Math.sin(wingPhase - 0.9);
        double w1 = wingBase + wingAmp * s;
        double w2 = 0.7 * wingBase - 5 + 0.8 * wingAmp * s2;
        q[WR1].rotateX((float) Math.toRadians(w1));
        q[WR2].rotateX((float) Math.toRadians(w2));
        q[WL1].rotateX((float) Math.toRadians(-w1));
        q[WL2].rotateX((float) Math.toRadians(-w2));
        q[NECK].rotateZ((float) Math.toRadians(-8 + neckBob));
        q[HEAD].rotateZ((float) Math.toRadians(6 - neckBob * 0.6));
        q[JAW].rotateZ((float) Math.toRadians(jawOpen));
        for (int k = 0; k < 6; k++) {
            double sway = 6 * Math.sin(wingPhase * 0.5 - k * 0.7) + tailKick * (k + 1) / 6.0 * (k % 2 == 0 ? 1 : 0.6);
            q[TAIL0 + k].rotateY((float) Math.toRadians(sway));
        }
        return q;
    }

    /** Her kemik icin ItemDisplay donusumu. Varlik konumu = govde merkezi. */
    private Transformation[] pose() {
        Quaternionf[] lq = localRots();
        Matrix4f[] m = new Matrix4f[NB];
        for (int i = 0; i < NB; i++) {
            float[] pv = BoneDragonRig.PIVOT[i];
            Matrix4f local = new Matrix4f().translate(pv[0], pv[1], pv[2]).rotate(lq[i]).translate(-pv[0], -pv[1], -pv[2]);
            int p = BoneDragonRig.PARENT[i];
            m[i] = p < 0 ? local : new Matrix4f(m[p]).mul(local);
        }
        float sc = (float) scale();
        Quaternionf br = bodyRot();
        float[] c = BoneDragonRig.CENTER;
        Transformation[] out = new Transformation[NB];
        for (int i = 0; i < NB; i++) {
            Matrix4f full = new Matrix4f().scale(sc).rotate(br).translate(-c[0], -c[1], -c[2]).mul(m[i]);
            Vector3f t = full.getTranslation(new Vector3f());
            Quaternionf r = full.getUnnormalizedRotation(new Quaternionf()).normalize();
            out[i] = new Transformation(t, r, new Vector3f(sc, sc, sc), new Quaternionf());
        }
        return out;
    }

    private void pushVisuals() {
        Transformation[] tr = pose();
        Location at = pos();
        for (int i = 0; i < parts.size(); i++) {
            ItemDisplay d = parts.get(i);
            if (d == null || d.isDead()) continue;
            d.setTeleportDuration(2);
            d.teleport(at);
            d.setInterpolationDuration(2);
            d.setInterpolationDelay(0);
            d.setTransformation(tr[i]);
        }
    }
}
