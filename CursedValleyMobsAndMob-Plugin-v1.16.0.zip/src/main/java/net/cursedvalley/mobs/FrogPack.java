package net.cursedvalley.mobs;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Frog;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Bataklik kurbagalari.
 *
 * Belirli bir kutu bolge icinde sabit sayida kurbaga tutar. Biri olunce
 * geri sayim baslar, sure dolunca bolgede rastgele bir noktada yenisi dogar.
 *
 * Bolgeden CIKAN kurbaga oyunculari birakip bolgenin ortasina yonelir ve
 * donerken cani hizla dolar -- yani oyuncular onlari bolgenin disina cekip
 * yipratamaz. Overlord'un tasma (leash) mantiginin kucuk hali.
 *
 * Can 50 oldugu icin vanilla can sistemi kullanilabiliyor (nitelik siniri
 * 1024). Bosslardaki gibi elle can tutmaya gerek yok; hasar, olum ve drop
 * normal akista isler -- yani ganimet kutusu sistemi kendiliginden calisir.
 */
public final class FrogPack {

    /** Kurbagalari isaretleyen etiket -- drop tablosu ve temizlik icin. */
    public static final String TAG = "cv_frog";

    /** Drop komutlarinda kullanilan ad: /cvmobs drop add swamp_frog <oran> */
    public static final String DROP_KEY = "swamp_frog";

    private final JavaPlugin plugin;

    // --- ayarlar ---
    private boolean enabled = true;
    private String worldName = "cursedvalley";
    private int count = 5;
    private double health = 50.0;
    private double sight = 4.0;
    private double meleeDamage = 4.0;
    private int meleeCooldownTicks = 20;
    private int respawnSeconds = 15;
    private double speed = 1.0;
    private double teleportDistance = 3.0;

    // Bolge kosesi (dahil): min/max
    private int minX, minY, minZ, maxX, maxY, maxZ;

    /** Yasayan kurbagalar. */
    private final List<UUID> alive = new ArrayList<>();
    /** Olenler icin kalan tick sayaclari. */
    private final List<Integer> respawnTimers = new ArrayList<>();

    private int tickCounter;

    public FrogPack(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    // ==================== AYAR ====================

    public void configure(org.bukkit.configuration.file.FileConfiguration c, String world) {
        this.worldName = world;
        enabled  = c.getBoolean("frogs.enabled", true);
        count    = Math.max(0, c.getInt("frogs.count", 5));
        health   = Math.max(1.0, Math.min(1024.0, c.getDouble("frogs.health", 50.0)));
        sight    = Math.max(1.0, c.getDouble("frogs.sight-range", 4.0));
        meleeDamage = Math.max(0.0, c.getDouble("frogs.melee-damage", 4.0));
        meleeCooldownTicks = Math.max(5, c.getInt("frogs.melee-cooldown-ticks", 20));
        respawnSeconds = Math.max(0, c.getInt("frogs.respawn-seconds", 15));
        speed = Math.max(0.05, c.getDouble("frogs.speed", 1.0));
        teleportDistance = Math.max(0.5, c.getDouble("frogs.leash-teleport-distance", 3.0));

        int x1 = c.getInt("frogs.region.x1", 15);
        int y1 = c.getInt("frogs.region.y1", -51);
        int z1 = c.getInt("frogs.region.z1", 210);
        int x2 = c.getInt("frogs.region.x2", 20);
        int y2 = c.getInt("frogs.region.y2", -51);
        int z2 = c.getInt("frogs.region.z2", 205);

        minX = Math.min(x1, x2); maxX = Math.max(x1, x2);
        minY = Math.min(y1, y2); maxY = Math.max(y1, y2);
        minZ = Math.min(z1, z2); maxZ = Math.max(z1, z2);
    }

    private World world() {
        return Bukkit.getWorld(worldName);
    }

    /** Bolgenin ortasi -- disari cikan kurbaganin donecegi nokta. */
    private Location center() {
        World w = world();
        if (w == null) return null;
        Location at = new Location(w,
                (minX + maxX) / 2.0 + 0.5,
                minY,
                (minZ + maxZ) / 2.0 + 0.5);
        return Ground.findNear(at, minY);
    }

    /**
     * Bolge disina cikma testi.
     *
     * Y'de tek katman verilmis olabilecegi icin (ornekte hepsi -51) dikeyde
     * bir miktar pay birakilir; yoksa kurbaga her zipladiginda "kacti"
     * sayilip donus moduna girerdi.
     */
    private boolean inside(Location l) {
        return l.getX() >= minX && l.getX() <= maxX + 1
            && l.getZ() >= minZ && l.getZ() <= maxZ + 1
            && l.getY() >= minY - 3 && l.getY() <= maxY + 5;
    }

    /** Sinirdan bu kadar uzaklasan kurbaga yurutulmez, dogrudan geri isinlanir. */
    private double outsideBy(Location l) {
        double dx = Math.max(0, Math.max(minX - l.getX(), l.getX() - (maxX + 1)));
        double dz = Math.max(0, Math.max(minZ - l.getZ(), l.getZ() - (maxZ + 1)));
        double dy = Math.max(0, Math.max((minY - 3) - l.getY(), l.getY() - (maxY + 5)));
        return Math.max(dy, Math.hypot(dx, dz));
    }

    // ==================== DOGUS ====================

    private Location randomSpot() {
        World w = world();
        if (w == null) return null;
        var r = ThreadLocalRandom.current();
        double x = minX + r.nextDouble() * (maxX - minX + 1);
        double z = minZ + r.nextDouble() * (maxZ - minZ + 1);
        Location at = new Location(w, x, minY, z);
        // Arena yeraltinda; yuzeye dogurmamak icin referans Y ile zemin aranir.
        return Ground.findNear(at, minY);
    }

    private void spawnOne() {
        Location at = randomSpot();
        if (at == null) return;
        World w = at.getWorld();

        Frog f = w.spawn(at, Frog.class, e -> {
            e.addScoreboardTag(TAG);
            // ONEMLI: persistent false olursa chunk bosalinca varlik silinir,
            // eklenti bunu "oldu" sanip 15 saniyede bir yenisini dogurur.
            e.setPersistent(true);
            e.setRemoveWhenFarAway(false);
            e.setAdult();
            e.setAware(true);

            var maxAttr = e.getAttribute(Attribute.MAX_HEALTH);
            if (maxAttr != null) maxAttr.setBaseValue(health);
            e.setHealth(health);

            // Vanilla kurbaganin takip menzili genistir; 4 bloga indiriliyor.
            var follow = e.getAttribute(Attribute.FOLLOW_RANGE);
            if (follow != null) follow.setBaseValue(sight);

            var mv = e.getAttribute(Attribute.MOVEMENT_SPEED);
            if (mv != null) mv.setBaseValue(mv.getBaseValue() * speed);

            e.customName(nameOf(health, health));
            e.setCustomNameVisible(true);
        });

        alive.add(f.getUniqueId());
    }

    /** Baslangicta / reload'da mevcut sayiyi hedefe tamamlar. */
    public void start() {
        removeAll();
        if (!enabled) return;
        for (int i = 0; i < count; i++) spawnOne();
    }

    // ==================== TICK ====================

    /** Her tick cagrilir; agir isler 10 tick'te bir yapilir. */
    public void tick() {
        if (!enabled) return;
        World w = world();
        if (w == null) return;

        // --- olenleri ayikla, geri sayimlari isle ---
        // Olum tespiti.
        //
        // DIKKAT: Bukkit.getEntity() yuklenmemis chunk'taki varlik icin de null
        // doner. Bunu "oldu" saymak, kimse kurbagalari oldurmese bile 15 saniyede
        // bir yeni kurbaga dogmasina yol aciyordu. Bu yuzden null = bilinmiyor
        // kabul edilir ve sayac BASLATILMAZ; sadece gercekten olen sayilir.
        Iterator<UUID> it = alive.iterator();
        while (it.hasNext()) {
            Entity e = Bukkit.getEntity(it.next());
            if (e == null) continue;                 // chunk yuklu degil, dokunma
            if (e.isDead() || !e.isValid()) {
                it.remove();
                respawnTimers.add(respawnSeconds * 20);
            }
        }

        for (int i = respawnTimers.size() - 1; i >= 0; i--) {
            int left = respawnTimers.get(i) - 1;
            if (left <= 0) {
                respawnTimers.remove(i);
                spawnOne();
            } else {
                respawnTimers.set(i, left);
            }
        }

        // Kayit listesi eksik kaldiysa (ornegin /kill ile silindiyse) tamamlanir.
        // Ust sinir count -- bu dongu artik kendi kendini besleyemez.
        while (alive.size() + respawnTimers.size() < count) {
            respawnTimers.add(respawnSeconds * 20);
        }

        if (++tickCounter % 10 != 0) return;

        // --- davranis ---
        Location home = center();
        for (UUID id : new ArrayList<>(alive)) {
            Entity e = Bukkit.getEntity(id);
            if (!(e instanceof Frog f)) continue;

            Location loc = f.getLocation();

            f.customName(nameOf(f.getHealth(), maxHealthOf(f)));

            if (!inside(loc)) {
                // Donus modu: oyuncu yok sayilir, can hizla dolar.
                f.setTarget(null);
                double max = maxHealthOf(f);
                f.setHealth(Math.min(max, f.getHealth() + max * 0.10));

                // Kurbaga vanilla AI ile ziplayarak gezinir; sadece "ortaya yuru"
                // demek 6x6'lik bir bolgede yetmiyor, surekli disari tasiyor.
                // Bu yuzden fazla uzaklasan dogrudan geri isinlanir.
                if (home != null) {
                    if (outsideBy(loc) > teleportDistance) {
                        f.teleport(home);
                    } else {
                        f.getPathfinder().moveTo(home, 1.3);
                    }
                }
                continue;
            }

            Player near = nearestPlayer(loc, sight);
            if (near == null) {
                f.setTarget(null);
                continue;
            }

            f.setTarget(near);
            f.getPathfinder().moveTo(near.getLocation(), 1.1);

            // Vanilla kurbaganin saldirisi yok -- vurus elle isleniyor.
            if (loc.distanceSquared(near.getLocation()) <= 2.6 * 2.6
                    && f.getTicksLived() - lastMelee(f) >= meleeCooldownTicks
                    && meleeDamage > 0) {
                near.damage(meleeDamage, f);
                setLastMelee(f, f.getTicksLived());
            }
        }
    }

    /** Overlord'daki gibi "ad + can / azami can" yazisi. */
    private static Component nameOf(double hp, double max) {
        int pct = (int) Math.round(100.0 * hp / Math.max(1.0, max));
        return Component.text("Bataklık Kurbağası ", NamedTextColor.DARK_GREEN)
                .append(Component.text(Math.round(hp) + " / " + Math.round(max),
                        pct > 50 ? NamedTextColor.GREEN
                                 : pct > 25 ? NamedTextColor.GOLD : NamedTextColor.RED));
    }

    private double maxHealthOf(LivingEntity e) {
        var a = e.getAttribute(Attribute.MAX_HEALTH);
        return a != null ? a.getValue() : health;
    }

    // Vurus bekleme suresi varligin uzerinde metadata olarak tutulur.
    private final java.util.Map<UUID, Integer> lastMeleeTick = new java.util.HashMap<>();

    private int lastMelee(Frog f) {
        return lastMeleeTick.getOrDefault(f.getUniqueId(), -1000);
    }

    private void setLastMelee(Frog f, int tick) {
        lastMeleeTick.put(f.getUniqueId(), tick);
    }

    private Player nearestPlayer(Location loc, double max) {
        Player best = null;
        double bestDist = max * max;
        for (Player p : loc.getWorld().getPlayers()) {
            if (p.isDead() || p.getGameMode() == org.bukkit.GameMode.SPECTATOR
                    || p.getGameMode() == org.bukkit.GameMode.CREATIVE) continue;
            double d = p.getLocation().distanceSquared(loc);
            if (d < bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }

    // ==================== TEMIZLIK ====================

    public boolean isFrog(Entity e) {
        return e != null && e.getScoreboardTags().contains(TAG);
    }

    public void removeAll() {
        for (UUID id : alive) {
            Entity e = Bukkit.getEntity(id);
            if (e != null) e.remove();
        }
        alive.clear();
        respawnTimers.clear();
        lastMeleeTick.clear();
    }

    /** Sunucu cokerse geride kalan kurbagalari siler. */
    public static void cleanupLeftovers(World w) {
        for (Entity e : w.getEntities()) {
            if (e.getScoreboardTags().contains(TAG)) e.remove();
        }
    }

    public int aliveCount() {
        return alive.size();
    }

    public int pendingCount() {
        return respawnTimers.size();
    }

    public boolean isEnabled() {
        return enabled;
    }
}
