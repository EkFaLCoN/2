package net.cursedvalley.mobs;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Bir yaratigin drop listesini oyuncuya salt-okunur bir envanter olarak gosterir.
 *
 * Her esyanin altinda dusme sansi yazar. Envanterden hicbir sey alinamaz.
 * Liste /cvmobs drop add ile doldurulan DropRegistry'den okunur; yani komutla
 * eklenen her sey burada kendiliginden gorunur.
 */
public final class DropPreview implements Listener {

    private final DropRegistry drops;

    public DropPreview(DropRegistry drops) {
        this.drops = drops;
    }

    /** Envanteri tanimak icin: sadece tiklamalari iptal etmek icin kullanilir. */
    private static final class View implements InventoryHolder {
        private Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    public void open(Player player, String title, String key) {
        List<DropRegistry.Entry> list = drops.entries(key);
        if (list.isEmpty()) {
            player.sendMessage(Component.text(title + " için kayıtlı drop yok.", NamedTextColor.GRAY));
            return;
        }

        int rows = Math.max(1, Math.min(6, (list.size() + 8) / 9));
        View holder = new View();
        holder.inv = Bukkit.createInventory(holder, rows * 9,
                Component.text(title + " — Droplar", NamedTextColor.DARK_PURPLE, TextDecoration.BOLD));

        int slot = 0;
        for (DropRegistry.Entry e : list) {
            if (slot >= rows * 9) break;
            ItemStack shown = e.item().clone();
            ItemMeta meta = shown.getItemMeta();
            if (meta != null) {
                List<Component> lore = meta.lore() != null ? new ArrayList<>(meta.lore()) : new ArrayList<>();
                lore.add(Component.empty());
                lore.add(Component.text("Düşme şansı: %" + percent(e.chance() * 100), NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false));
                meta.lore(lore);
                shown.setItemMeta(meta);
            }
            holder.inv.setItem(slot++, shown);
        }

        player.openInventory(holder.inv);
        player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, SoundCategory.PLAYERS, 0.6f, 1.3f);
    }

    /** Kucuk oranlar "0" gorunmesin: 6 basamaga kadar, gereksiz sifirsiz. */
    static String percent(double v) {
        BigDecimal bd = new BigDecimal(v).setScale(6, RoundingMode.HALF_UP);
        if (bd.signum() == 0) return "0";
        return bd.stripTrailingZeros().toPlainString();
    }

    // ---- salt okunur: hicbir sey alinip konamaz ----

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof View) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof View) {
            event.setCancelled(true);
        }
    }
}
