package net.cursedvalley.mobs;

import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * DropByDrop'taki tum cop esyalari (378) ortak havuz olarak DropRegistry'ye yukler.
 * DropByDrop'a yansima ile baglanir (yumusak bagimlilik). Esya kademesi kimliginin
 * sonundaki sayidir (ornek: savasci_sword_6 -> 6).
 */
public final class JunkDrops {

    private JunkDrops() {
    }

    private static boolean junk(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return false;
        ItemMeta m = it.getItemMeta();
        return m.hasItemModel() && m.getItemModel() != null
                && "dropbydrop".equals(m.getItemModel().getNamespace());
    }

    /** @return havuzdaki esya sayisi; DropByDrop yoksa -1 */
    public static int sync(DropRegistry drops) {
        Plugin p = Bukkit.getPluginManager().getPlugin("DropByDrop");
        if (p == null || !p.isEnabled()) return -1;
        try {
            Object katalog = p.getClass().getMethod("katalog").invoke(p);
            List<?> tanimlar = (List<?>) katalog.getClass().getMethod("hepsi").invoke(katalog);
            Method uret = null;
            for (Method m : katalog.getClass().getMethods()) {
                if (m.getName().equals("uret") && m.getParameterCount() == 1) uret = m;
            }
            if (uret == null) return -1;

            // Onceki surumden config'e yazilmis cop kayitlarini temizle (artik ortak havuz var)
            for (String mob : drops.mobNames()) {
                drops.entries(mob).removeIf(e -> junk(e.item()));
            }
            List<DropRegistry.Junk> pool = new ArrayList<>();
            for (Object t : tanimlar) {
                ItemStack it = (ItemStack) uret.invoke(katalog, t);
                String key = it.getItemMeta().getItemModel().getKey();
                int tier = 1;
                try {
                    tier = Integer.parseInt(key.substring(key.lastIndexOf('_') + 1));
                } catch (RuntimeException ignored) {
                    // kademe okunamazsa 1
                }
                pool.add(new DropRegistry.Junk(it, Math.max(1, Math.min(7, tier))));
            }
            drops.setJunkPool(pool);
            return pool.size();
        } catch (ReflectiveOperationException | RuntimeException e) {
            Bukkit.getLogger().warning("[CursedValleyMobs] DropByDrop cop esyalari yuklenemedi: " + e);
            return -1;
        }
    }
}
