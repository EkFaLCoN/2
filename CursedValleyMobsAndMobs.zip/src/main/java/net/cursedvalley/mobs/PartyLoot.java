package net.cursedvalley.mobs;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Ganimet sahibi secimi: EN COK HASAR veren oyuncu (veya partisi) kazanir.
 *
 * Parti yonetimi AYRI eklentide (PartySistemi); burasi ona reflection ile baglanir.
 * PartySistemi yoksa herkes tek basina sayilir. Parti kazanirsa ganimet olum
 * noktasina "loot-range" blok icindeki uyelere sirayla dusurulur ve coinler
 * (toplam / kisi sayisi + bonus) olarak paylastirilir.
 */
public final class PartyLoot implements Listener {

    /** Olum cozumlemesinin sonucu. */
    public record Result(Player recipient, List<Player> shared, int partySize) {
        public boolean isParty() {
            return shared != null;
        }
    }

    private final JavaPlugin plugin;
    private final Map<UUID, Map<UUID, Double>> damage = new HashMap<>();

    private double lootRange = 20.0;
    private double bonusPercent = 25.0;
    private double fullPartyPercent = 20.0;
    private int fullPartySize = 8;
    private String payCommand = "";
    private final Map<String, int[]> coins = new HashMap<>();

    public PartyLoot(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void configure(FileConfiguration c) {
        String p = "party.";
        lootRange = Math.max(1.0, c.getDouble(p + "loot-range", 20.0));
        bonusPercent = Math.max(0.0, c.getDouble(p + "coin-bonus-percent", 25.0));
        fullPartyPercent = Math.max(0.0, c.getDouble(p + "full-party-bonus-percent", 20.0));
        fullPartySize = Math.max(2, c.getInt(p + "full-party-size", 8));
        payCommand = c.getString(p + "pay-command", "");
        if (payCommand == null) payCommand = "";
        payCommand = payCommand.trim();
        if (payCommand.startsWith("/")) payCommand = payCommand.substring(1);

        coins.clear();
        ConfigurationSection sec = c.getConfigurationSection(p + "coins");
        if (sec != null) {
            for (String name : sec.getKeys(false)) {
                List<Integer> r = sec.getIntegerList(name);
                if (r.size() >= 2) {
                    int lo = Math.min(r.get(0), r.get(1));
                    int hi = Math.max(r.get(0), r.get(1));
                    coins.put(name.trim().toLowerCase(Locale.ROOT), new int[]{lo, hi});
                }
            }
        }
    }

    // ==================== HASAR TAKIBI ====================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof LivingEntity victim) || victim instanceof Player) return;
        Player attacker = null;
        if (e.getDamager() instanceof Player p) {
            attacker = p;
        } else if (e.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player p2) {
            attacker = p2;
        }
        if (attacker == null) return;
        double d = e.getFinalDamage();
        if (d <= 0) return;
        damage.computeIfAbsent(victim.getUniqueId(), k -> new HashMap<>())
                .merge(attacker.getUniqueId(), d, Double::sum);
        if (damage.size() > 400) prune();
    }

    private void prune() {
        damage.keySet().removeIf(id -> {
            Entity en = Bukkit.getEntity(id);
            return en == null || en.isDead();
        });
    }

    // ---- PartySistemi koprusu (reflection; kod bagimliligi yok) ----

    private Object partyPlugin() {
        Plugin pl = Bukkit.getPluginManager().getPlugin("PartySistemi");
        return pl != null && pl.isEnabled() ? pl : null;
    }

    private UUID leaderOf(UUID id) {
        Object pl = partyPlugin();
        if (pl == null) return null;
        try {
            return (UUID) pl.getClass().getMethod("getLeaderOf", UUID.class).invoke(pl, id);
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    private List<UUID> membersOf(UUID id) {
        Object pl = partyPlugin();
        if (pl == null) return List.of();
        try {
            return (List<UUID>) pl.getClass().getMethod("getMembersOf", UUID.class).invoke(pl, id);
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return List.of();
        }
    }

    private UUID nextInRotation(UUID id, Collection<UUID> eligible) {
        Object pl = partyPlugin();
        if (pl == null) return null;
        try {
            return (UUID) pl.getClass().getMethod("nextInRotation", UUID.class, Collection.class)
                    .invoke(pl, id, eligible);
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return null;
        }
    }

    /**
     * Olen yaratigin ganimet sahibini bulur.
     *
     * @param fallback hasar kaydi yoksa kullanilacak son vuran (olabilir: null)
     * @return alici yoksa null
     */
    public Result resolve(LivingEntity dead, Player fallback) {
        Map<UUID, Double> map = damage.remove(dead.getUniqueId());
        if (map == null || map.isEmpty()) {
            return fallback != null && fallback.isOnline() ? new Result(fallback, null, 0) : null;
        }

        // Parti uyelerinin hasari partide toplanir; yalnizlar kendi basina.
        Map<UUID, Double> groups = new HashMap<>();    // lider veya oyuncu id -> toplam
        Map<UUID, UUID> anyMember = new HashMap<>();   // grup anahtari -> bir uye
        for (Map.Entry<UUID, Double> en : map.entrySet()) {
            UUID leader = leaderOf(en.getKey());
            UUID key = leader != null ? leader : en.getKey();
            groups.merge(key, en.getValue(), Double::sum);
            anyMember.putIfAbsent(key, en.getKey());
        }
        UUID bestKey = null;
        double best = -1;
        for (Map.Entry<UUID, Double> en : groups.entrySet()) {
            if (en.getValue() > best) {
                best = en.getValue();
                bestKey = en.getKey();
            }
        }
        if (bestKey == null) return null;

        List<UUID> members = membersOf(anyMember.get(bestKey));
        if (!members.isEmpty()) {
            List<Player> near = membersNear(members, dead.getLocation());
            if (!near.isEmpty()) {
                List<UUID> ids = new ArrayList<>();
                for (Player p : near) ids.add(p.getUniqueId());
                UUID next = nextInRotation(anyMember.get(bestKey), ids);
                Player pick = next != null ? Bukkit.getPlayer(next) : near.get(0);
                if (pick == null) pick = near.get(0);
                return new Result(pick, near, members.size());
            }
            // Kimse yakin degil: partide en cok vuran cevrimici uyeye ver.
            Player top = topOnline(map, members);
            if (top != null) return new Result(top, null, 0);
            return fallback != null && fallback.isOnline() ? new Result(fallback, null, 0) : null;
        }

        Player solo = Bukkit.getPlayer(bestKey);
        if (solo != null && solo.isOnline()) return new Result(solo, null, 0);
        return fallback != null && fallback.isOnline() ? new Result(fallback, null, 0) : null;
    }

    private Player topOnline(Map<UUID, Double> map, List<UUID> only) {
        Player best = null;
        double bd = -1;
        for (UUID id : only) {
            Double d = map.get(id);
            Player p = Bukkit.getPlayer(id);
            if (d != null && p != null && p.isOnline() && d > bd) {
                bd = d;
                best = p;
            }
        }
        return best;
    }

    private List<Player> membersNear(List<UUID> members, Location at) {
        List<Player> out = new ArrayList<>();
        double r2 = lootRange * lootRange;
        for (UUID id : members) {
            Player p = Bukkit.getPlayer(id);
            if (p == null || !p.isOnline() || p.isDead()) continue;
            if (p.getGameMode() == GameMode.SPECTATOR) continue;
            if (!p.getWorld().equals(at.getWorld())) continue;
            if (p.getLocation().distanceSquared(at) <= r2) out.add(p);
        }
        return out;
    }

    /** Parti ganimetinin kime dustugunu partiye bildirir. */
    public void announce(Result res, String mobName) {
        if (res == null || !res.isParty()) return;
        Component msg = Component.text("[Parti] ", NamedTextColor.GREEN)
                .append(Component.text(mobName + " ganimeti → ", NamedTextColor.GRAY))
                .append(Component.text(res.recipient().getName(), NamedTextColor.YELLOW));
        for (Player p : res.shared()) p.sendMessage(msg);
    }

    // ==================== COIN PAYLASIMI ====================

    private int[] coinRange(ItemStack it) {
        if (it == null || it.getType().isAir()) return null;
        ItemMeta meta = it.getItemMeta();
        if (meta == null) return null;
        Component c = null;
        if (meta.hasDisplayName()) c = meta.displayName();
        else if (meta.hasItemName()) c = meta.itemName();
        if (c == null) return null;
        String name = PlainTextComponentSerializer.plainText().serialize(c).trim().toLowerCase(Locale.ROOT);
        return coins.get(name);
    }

    /**
     * Ganimetteki coin esyalarini cikarip paraya cevirir ve {@code share} listesine
     * (toplam / kisi sayisi + bonus) olarak dagitir.
     *
     * pay-command bos ise hicbir sey yapmaz; coin esyalari sandikta kalir.
     *
     * @return coinleri cikarilmis liste (degisiklik yoksa ayni liste)
     */
    public List<ItemStack> splitCoins(List<ItemStack> loot, List<Player> share, int partySize) {
        if (payCommand.isEmpty() || share == null || share.isEmpty() || coins.isEmpty()) return loot;

        List<ItemStack> rest = new ArrayList<>();
        long total = 0;
        boolean any = false;
        var rnd = ThreadLocalRandom.current();
        for (ItemStack it : loot) {
            int[] r = coinRange(it);
            if (r == null) {
                rest.add(it);
                continue;
            }
            any = true;
            for (int i = 0; i < it.getAmount(); i++) {
                total += r[0] + rnd.nextInt(r[1] - r[0] + 1);
            }
        }
        if (!any) return loot;

        // Kisi payi = toplam / kisi sayisi; ustune parti bonusu (%), parti doluysa ekstra bonus.
        double pct = bonusPercent + (partySize >= fullPartySize ? fullPartyPercent : 0.0);
        double base = (double) total / share.size();
        long each = Math.round(base * (1.0 + pct / 100.0));
        for (Player p : share) {
            String cmd = payCommand
                    .replace("%player%", p.getName())
                    .replace("%amount%", Long.toString(each));
            boolean ok = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            if (!ok) {
                plugin.getLogger().warning("party.pay-command çalışmadı: " + cmd);
            }
            p.sendMessage(Component.text("[Parti] ", NamedTextColor.GREEN)
                    .append(Component.text("Coin payın: ", NamedTextColor.GRAY))
                    .append(Component.text(each + " TL", NamedTextColor.GOLD))
                    .append(Component.text(" (" + Math.round(base) + " pay + %" + Math.round(pct) + " bonus)", NamedTextColor.DARK_GRAY)));
        }
        return rest;
    }
}
