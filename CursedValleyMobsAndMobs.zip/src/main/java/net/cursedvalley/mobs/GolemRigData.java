package net.cursedvalley.mobs;

/**
 * End Golem rig verisi -- ELLE DUZENLEME.
 *
 * Bu dosya, modelin GLB halinden otomatik uretildi: her satir bir kupun
 * (item_display) duran halindeki dondurmesi (quaternion x,y,z,w) ve model
 * koordinatindaki merkez konumudur. Koordinatlar modelin kendi uzayindadir:
 * model -X yonune bakar, 1 birim = 1 blok, ayaklar y ~ -0.14.
 */
final class GolemRigData {

    private GolemRigData() {
    }

    record Part(String name, String bone,
                float qx, float qy, float qz, float qw,
                float tx, float ty, float tz) {
    }

    static final Part[] PARTS = {
            new Part("pelvis", "body", 0.0000000f, 0.0000000f, 0.0654031f, 0.9978589f, -0.123236f, 1.654317f, -0.031250f),
            new Part("chest", "body", 0.0000000f, 0.0000000f, 0.0871557f, 0.9961947f, -0.301950f, 2.612253f, 0.000000f),
            new Part("head", "head", 0.0000000f, 0.0000000f, 0.0000000f, 1.0000000f, -0.562500f, 3.812500f, 0.000000f),
            new Part("leg_a_0", "leg_a", 0.0000000f, 0.0000000f, -0.0654031f, 0.9978589f, -0.237187f, 1.071375f, -0.750000f),
            new Part("leg_a_1", "leg_a", 0.0000000f, 0.0000000f, 0.1305262f, 0.9914449f, -0.179525f, 0.307773f, -0.750000f),
            new Part("leg_b_0", "leg_b", 0.0000000f, 0.0000000f, -0.0654031f, 0.9978589f, -0.237187f, 1.071375f, 0.750000f),
            new Part("leg_b_1", "leg_b", 0.0000000f, 0.0000000f, 0.1305262f, 0.9914449f, -0.179525f, 0.307773f, 0.750000f),
            new Part("arm_a_0", "arm_a", 0.6900325f, -0.0452271f, 0.7208173f, 0.0472449f, -0.504764f, 2.326160f, 1.315891f),
            new Part("arm_a_1", "arm_a", 0.6900325f, -0.0452271f, 0.7208173f, 0.0472449f, -0.545554f, 2.016333f, 1.315891f),
            new Part("arm_a_2", "arm_a", 0.6900325f, -0.0452271f, 0.7208173f, 0.0472449f, -0.720948f, 0.684079f, 1.315891f),
            new Part("arm_b_0", "arm_b", 0.6900325f, -0.0452271f, 0.7208173f, 0.0472449f, -0.453149f, 2.319364f, -1.309337f),
            new Part("arm_b_1", "arm_b", 0.6900325f, -0.0452271f, 0.7208173f, 0.0472449f, -0.483647f, 2.008183f, -1.306383f),
            new Part("arm_b_2", "arm_b", 0.6900325f, -0.0452271f, 0.7208173f, 0.0472449f, -0.659042f, 0.675929f, -1.306383f),
    };
}
