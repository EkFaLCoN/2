package net.cursedvalley.mobs;

/** Bone Dragon kemik tablosu (gen/convert_dragon.py tarafindan uretilir; elle degistirme). */
final class BoneDragonRig {
    private BoneDragonRig() {}

    static final String[] NAMES = {"body", "neck", "head", "jaw", "wr1", "wr2", "wl1", "wl2", "t1", "t2", "t3", "t4", "t5", "t6"};
    static final int[] PARENT = {-1, 0, 1, 2, 0, 4, 0, 6, 0, 8, 9, 10, 11, 12};
    /** Her kemigin donme noktasi (modelin kendi birimi: 1 birim = 1 blok olcek=1 iken). */
    static final float[][] PIVOT = {
        {0.0f, 1.5f, 0.0f},
        {-1.8603f, 2.1345f, 0.0f},
        {-2.8791f, 2.7425f, 0.0f},
        {-3.0629f, 2.1932f, 0.0f},
        {-0.24f, 1.81f, 0.0f},
        {-1.5936f, 2.2111f, -1.0904f},
        {-0.24f, 1.81f, 0.0f},
        {-1.3663f, 2.2284f, 1.1986f},
        {1.646f, 1.4133f, 0.0f},
        {2.2362f, 1.3304f, 0.0f},
        {2.7403f, 1.2559f, 0.0f},
        {3.1914f, 1.2117f, 0.0f},
        {3.6094f, 1.1359f, 0.0f},
        {3.9398f, 1.0961f, 0.0f}
    };
    /** Govde merkezi: varligin konumu bu noktaya denk gelir. */
    static final float[] CENTER = {0f, 1.4f, 0f};
}
