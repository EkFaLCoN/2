package net.cursedvalley.mobs;

import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Transformation;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Tek bir End Golem'in gorunumu.
 *
 * Vanilla Iron Golem gorunmez yapilir (hitbox'i modele en yakin olan yaratik); uzerine 13 adet item_display "parca" takilir
 * (cursedvalley:end_golem/...). Her parca modeldeki bir kup: duran dondurmesi
 * GolemRigData'da, animasyon (yurume, vurus) burada hesaplanir ve her parcanin
 * Transformation'ina yazilir. Datapack'e dokunulmaz, komut cagrilmaz.
 */
public final class EndGolemModel {

    public static final String PART_TAG = "cv_golem_part";

    /** Modelin ayaklari y=-0.14'te; yere oturtmak icin bu kadar yukari alinir. */
    private static final float FOOT = 0.14f;
    /** Model boyu (blok, olcek 1). Hitbox ve isim etiketi bundan hesaplanir. */
    public static final float HEIGHT = 4.45f;

    // Eklem noktalari (model uzayi). Model -X yonune bakar; kollar/bacaklar Z ekseni
    // etrafinda doner. Pozitif aci alt ucu +X'e (geriye) savurur, onde ileri = negatif.
    private static final Vector3f ARM_A = new Vector3f(-0.50f, 3.05f, 1.32f);
    private static final Vector3f ARM_B = new Vector3f(-0.50f, 3.05f, -1.30f);
    private static final Vector3f LEG_A = new Vector3f(-0.18f, 1.35f, -0.75f);
    private static final Vector3f LEG_B = new Vector3f(-0.18f, 1.35f, 0.75f);

    private final JavaPlugin plugin;
    private final float scale;
    private final ItemDisplay[] displays = new ItemDisplay[GolemRigData.PARTS.length];
    private TextDisplay nameTag;

    private Location last;
    private Location lastSent;
    private float lastYaw = Float.NaN;
    private double walkPhase;
    private float walkAmp;
    private long lastStep = Long.MIN_VALUE;

    /** Vurus animasyonu: tick sayaci (-1 = yok). */
    private int atkTick = -1;

    /** En son gonderilen degerler: degismediyse paket yollanmaz. */
    private float sentSwing = Float.NaN, sentArm = Float.NaN, sentBob = Float.NaN;
    private boolean dirty = true;

    public EndGolemModel(JavaPlugin plugin, float scale) {
        this.plugin = plugin;
        this.scale = scale;
    }

    // ==================== YASAM DONGUSU ====================

    public void spawn(IronGolem giant) {
        remove();
        World w = giant.getWorld();
        Location loc = giant.getLocation();

        for (int i = 0; i < GolemRigData.PARTS.length; i++) {
            GolemRigData.Part p = GolemRigData.PARTS[i];
            displays[i] = w.spawn(loc, ItemDisplay.class, e -> {
                e.setItemStack(partItem(p.name()));
                e.setBillboard(Display.Billboard.FIXED);
                e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);
                e.setViewRange(2.5f);
                e.setPersistent(false);
                e.setBrightness(new Display.Brightness(12, 12));
                e.setTeleportDuration(2);
                e.setInterpolationDuration(2);
                e.addScoreboardTag(PART_TAG);
            });
        }

        // Can yazisi golemin UZERINE BINER; elle isinlanirsa geride kaliyordu.
        nameTag = w.spawn(loc.clone().add(0, 1, 0), TextDisplay.class, e -> {
            e.setBillboard(Display.Billboard.CENTER);
            e.setSeeThrough(true);
            e.setPersistent(false);
            e.setViewRange(1.2f);
            e.setTeleportDuration(2);
            e.setBrightness(new Display.Brightness(15, 15));
            e.addScoreboardTag(PART_TAG);
            e.setTransformation(new Transformation(
                    new Vector3f(0f, 0.55f, 0f), new Quaternionf(),
                    new Vector3f(1.1f, 1.1f, 1.1f), new Quaternionf()));
            Component n = giant.customName();
            if (n != null) e.text(n);
        });
        giant.addPassenger(nameTag);

        giant.setInvisible(true);
        giant.setCustomNameVisible(false);

        last = null;
        lastSent = null;
        lastYaw = Float.NaN;
        walkPhase = 0;
        walkAmp = 0;
        atkTick = -1;
        dirty = true;
        sentSwing = sentArm = sentBob = Float.NaN;
    }

    /** Tum parcalar yasiyor mu? Chunk bosalip yuklenince parcalar silinmis olabilir. */
    public boolean valid() {
        if (nameTag == null || nameTag.isDead() || !nameTag.isValid()) return false;
        for (ItemDisplay d : displays) {
            if (d == null || d.isDead() || !d.isValid()) return false;
        }
        return true;
    }

    public void remove() {
        if (nameTag != null && !nameTag.isDead()) nameTag.remove();
        nameTag = null;
        for (int i = 0; i < displays.length; i++) {
            if (displays[i] != null && !displays[i].isDead()) displays[i].remove();
            displays[i] = null;
        }
        last = null;
        lastSent = null;
    }

    /** Sunucu acilisinda dunyada kalmis parcalari temizler. */
    public static void cleanupLeftovers(World w) {
        if (w == null) return;
        for (Entity e : w.getEntities()) {
            if (e.getScoreboardTags().contains(PART_TAG)) e.remove();
        }
    }

    public void setName(Component name) {
        if (nameTag != null && !nameTag.isDead()) nameTag.text(name);
    }

    private ItemStack partItem(String part) {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta m = it.getItemMeta();
        m.setItemModel(new NamespacedKey("cursedvalley", "end_golem/" + part));
        it.setItemMeta(m);
        return it;
    }

    // ==================== ANIMASYON TETIKLERI ====================

    /** Iki kol havaya kalkar, yere iner. Hasar, animasyonun inis aninda verilir. */
    public void playAttack() {
        atkTick = 0;
        dirty = true;
    }

    // ==================== HER TICK ====================

    /**
     * @param step bu cagrinin kac tick'i temsil ettigi (animasyon hizi buna bagli)
     */
    public void tick(IronGolem giant, int step) {
        if (giant == null || giant.isDead() || !valid()) return;

        Location loc = giant.getLocation();
        float yaw = giant.getBodyYaw();

        // --- yurume fazi: gercek yer degistirmeye gore ilerler ---
        double speed = 0;
        if (last != null && last.getWorld() == loc.getWorld()) {
            double dx = loc.getX() - last.getX();
            double dz = loc.getZ() - last.getZ();
            speed = Math.sqrt(dx * dx + dz * dz) / Math.max(1, step);   // tick basina
        }
        last = loc.clone();
        walkPhase += Math.min(0.5, speed * 2.6) * step;
        walkAmp += ((speed > 0.012 ? 1f : 0f) - walkAmp) * (0.25f * step / 2f);
        if (walkAmp < 0.01f && speed <= 0.012) walkAmp = 0f;

        float swing = (float) (Math.toRadians(30) * Math.sin(walkPhase)) * walkAmp;
        float bob = (float) (Math.abs(Math.sin(walkPhase)) * 0.07) * walkAmp;

        // agir adim sesi: her yarim salinimda bir ayak yere basar
        long half = (long) Math.floor(walkPhase / Math.PI);
        if (walkAmp > 0.45f && half != lastStep) {
            lastStep = half;
            World w = loc.getWorld();
            w.playSound(loc, Sound.ENTITY_IRON_GOLEM_STEP, SoundCategory.HOSTILE, 1.4f, 0.55f);
        }

        // --- vurus: iki kol birlikte kalkar, iner ---
        float arm = 0f;
        if (atkTick >= 0) {
            atkTick += step;
            int t = atkTick;
            if (t < 6) {
                arm = lerp(0f, -140f, smooth(t / 6f));
            } else if (t < 9) {
                arm = lerp(-140f, 15f, (t - 6) / 3f);
            } else if (t < 16) {
                arm = lerp(15f, 0f, (t - 9) / 7f);
            } else {
                atkTick = -1;
                arm = 0f;
            }
            arm = (float) Math.toRadians(arm);
        }

        // --- konum / yon: yalnizca gerektiginde isinla ---
        boolean moved = lastSent == null
                || lastSent.getWorld() != loc.getWorld()
                || lastSent.distanceSquared(loc) > 0.0004
                || Math.abs(lastYaw - yaw) > 0.6f;
        if (moved) {
            Location base = loc.clone();
            base.setPitch(0f);
            base.setYaw(yaw);
            lastSent = loc.clone();
            lastYaw = yaw;
            for (ItemDisplay d : displays) {
                if (d != null && !d.isDead()) d.teleport(base);
            }
        }

        // --- donusumler: degisiklik yoksa gonderme ---
        boolean changed = dirty
                || Float.isNaN(sentSwing)
                || Math.abs(swing - sentSwing) > 0.004f
                || Math.abs(arm - sentArm) > 0.004f
                || Math.abs(bob - sentBob) > 0.004f;
        if (!changed) return;
        dirty = false;
        sentSwing = swing;
        sentArm = arm;
        sentBob = bob;

        for (int i = 0; i < displays.length; i++) {
            ItemDisplay d = displays[i];
            if (d == null || d.isDead()) continue;
            GolemRigData.Part p = GolemRigData.PARTS[i];

            Vector3f pivot = null;
            float phi = 0f;
            switch (p.bone()) {
                case "leg_a" -> { pivot = LEG_A; phi = -swing; }
                case "leg_b" -> { pivot = LEG_B; phi = swing; }
                // kol, ayni taraftaki bacagin tersine salinir
                case "arm_a" -> { pivot = ARM_A; phi = -swing * 0.7f + arm; }
                case "arm_b" -> { pivot = ARM_B; phi = swing * 0.7f + arm; }
                default -> { }
            }

            Matrix4f m = new Matrix4f()
                    .scale(scale)
                    // Govde ve animasyonlar bu yonle dogru calisiyor (oyunda denendi).
                    // Gozler ise ters tarafta kaliyordu; bu yuzden SADECE kafa asagida
                    // kendi ekseninde 180 derece cevrilir.
                    .rotateY((float) (Math.PI / 2))
                    .translate(0f, FOOT + bob, 0f);
            if (pivot != null) {
                m.translate(pivot).rotateZ(phi).translate(-pivot.x, -pivot.y, -pivot.z);
            }
            m.translate(p.tx(), p.ty(), p.tz());
            // Kafa: kendi merkezinde 180 derece doner (konumu degismez, gozler one bakar).
            if (p.bone().equals("head")) m.rotateY((float) Math.PI);
            m.rotate(new Quaternionf(p.qx(), p.qy(), p.qz(), p.qw()));

            Vector3f tr = m.getTranslation(new Vector3f());
            Quaternionf rot = m.getUnnormalizedRotation(new Quaternionf());
            Vector3f sc = m.getScale(new Vector3f());

            d.setInterpolationDelay(0);
            d.setInterpolationDuration(2);
            d.setTransformation(new Transformation(tr, rot, sc, new Quaternionf()));
        }
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * Math.max(0f, Math.min(1f, t));
    }

    private static float smooth(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return t * t * (3f - 2f * t);
    }
}
