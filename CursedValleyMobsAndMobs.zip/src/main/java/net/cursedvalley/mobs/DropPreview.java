package net.cursedvalley.mobs;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Bir yaratigin drop listesini oyuncuya salt-okunur bir envanter olarak gosterir.
 *
 * Her esyanin altinda dusme sansi yazar. Envanterden hicbir sey alinamaz.
 * Liste /cvmobs drop add ile doldurulan DropRegistry'den okunur; yani komutla
 * eklenen her sey burada kendiliginden gorunur.
 */
public final class DropPreview implements Listener {

    private final DropRegistry drops;

    public DropPreview(DropRegistry drops) {
        this.drops = drops;
    }

    /** Envanteri tanimak icin; sayfa ve liste bilgisini tasir. */
    private static final class View implements InventoryHolder {
        private Inventory inv;
        private String title;
        private String key;
        private int page;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private static final int PER_PAGE = 45;
    private static final int PREV = 45, INFO = 49, NEXT = 53;

    public void open(Player player, String title, String key) {
        if (drops.entries(key).isEmpty()) {
            player.sendMessage(Component.text(title + " için kayıtlı drop yok.", NamedTextColor.GRAY));
            return;
        }
        View holder = new View();
        holder.title = title;
        holder.key = key;
        holder.page = 0;
        build(holder, player);
        player.openInventory(holder.inv);
        player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, SoundCategory.PLAYERS, 0.6f, 1.3f);
    }

    /** Sayfayi doldurur. 54 ve alti esya tek sayfada, nav satiri olmadan gorunur. */
    private void build(View holder, Player player) {
        List<DropRegistry.Entry> list = drops.entries(holder.key);
        boolean paged = list.size() > 54;
        int perPage = paged ? PER_PAGE : 54;
        int pages = Math.max(1, (list.size() + perPage - 1) / perPage);
        holder.page = Math.max(0, Math.min(holder.page, pages - 1));

        int rows = paged ? 6 : Math.max(1, (list.size() + 8) / 9);
        Component t = Component.text(holder.title + " — Droplar"
                + (paged ? " (" + (holder.page + 1) + "/" + pages + ")" : ""),
                NamedTextColor.DARK_PURPLE, TextDecoration.BOLD);
        Inventory inv = holder.inv;
        if (inv == null || inv.getSize() != rows * 9 || paged) {
            inv = Bukkit.createInventory(holder, rows * 9, t);
            holder.inv = inv;
        } else {
            inv.clear();
        }

        int from = holder.page * perPage;
        int to = Math.min(list.size(), from + perPage);
        int slot = 0;
        for (int i = from; i < to; i++) {
            DropRegistry.Entry e = list.get(i);
            ItemStack shown = e.item().clone();
            ItemMeta meta = shown.getItemMeta();
            if (meta != null) {
                List<Component> lore = meta.lore() != null ? new ArrayList<>(meta.lore()) : new ArrayList<>();
                lore.add(Component.empty());
                lore.add(Component.text("Düşme şansı: %" + percent(e.chance() * 100), NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false));
                meta.lore(lore);
                shown.setItemMeta(meta);
            }
            inv.setItem(slot++, shown);
        }
        if (paged) {
            if (holder.page > 0) inv.setItem(PREV, nav("◀ Önceki sayfa"));
            if (holder.page < pages - 1) inv.setItem(NEXT, nav("Sonraki sayfa ▶"));
            inv.setItem(INFO, nav("Sayfa " + (holder.page + 1) + "/" + pages + " (" + list.size() + " drop)"));
        }
    }

    private static ItemStack nav(String text) {
        ItemStack it = new ItemStack(org.bukkit.Material.ARROW);
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text(text, NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false));
        it.setItemMeta(m);
        return it;
    }

    /** Kucuk oranlar "0" gorunmesin: 6 basamaga kadar, gereksiz sifirsiz. */
    static String percent(double v) {
        BigDecimal bd = new BigDecimal(v).setScale(6, RoundingMode.HALF_UP);
        if (bd.signum() == 0) return "0";
        return bd.stripTrailingZeros().toPlainString();
    }

    // ---- salt okunur: hicbir sey alinip konamaz ----

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof View v) {
            event.setCancelled(true);
            if (event.getClickedInventory() == event.getView().getTopInventory()
                    && event.getWhoClicked() instanceof Player pl) {
                int sl = event.getRawSlot();
                if (v.inv.getSize() == 54 && drops.entries(v.key).size() > 54) {
                    if (sl == PREV && v.page > 0) { v.page--; build(v, pl); pl.openInventory(v.inv); }
                    else if (sl == NEXT) { v.page++; build(v, pl); pl.openInventory(v.inv); }
                }
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof View) {
            event.setCancelled(true);
        }
    }
}
